<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- Field captures go to a localStorage queue (src/lib/offline.ts) with client-generated UUIDs and are upserted with ignoreDuplicates — so resending after reconnect never duplicates rows.
- Catalogs and the user's roles are cached locally; the auth gate falls back to getSession() when offline — so the field app opens without signal.
- Service worker registration lives only in src/lib/pwa.ts with preview/dev guards — so the editor preview never serves stale caches.
- Business limits live in src/lib/reglas.ts and are mirrored by DB check constraints — so client and server enforce the same rule.
- Customer/order control is staff-only in RLS; dispatches optionally reference orders and DB triggers validate matching customer/product — so offline captures and later assignment share the same integrity rules.
- Order delivery progress is derived from linked dispatches in src/lib/avance-pedidos.ts; only confirmed deliveries count as received — so sent trucks are never confused with received volume.
- Species weight conversions live in src/lib/reglas.ts; capture converts tonnes into persisted m³ before capacity validation and queueing — so inventory and order progress keep one canonical unit.
- Operational lineage and driver names are saved on each dispatch; monthly reports aggregate dispatch records, not imported spreadsheet summaries — so historical journeys remain traceable without inferring links between Excel sheets.
- Company attribution is stored on each dispatch, never inferred from vehicle carriers; operational aggregation lives in src/lib/resumen-operacion.ts and driver frequency groups by normalized name across vehicles and companies — so third-party trucks never shift company productivity.
- Operational settings editors live in src/components/ajustes-operacion.tsx; production lines are an admin-managed catalog cached for offline capture, while dispatches retain their captured line names — so catalog renames do not rewrite operational history.
- Session persistence policy lives in src/lib/auth-persistence.ts and runs before session reads; opted-out sessions require a tab marker, leaving offline capture storage untouched. The generated auth storage is never modified.
- The author signature is rendered once in the root shell so every route, including errors and recovery, shares it without duplication.
