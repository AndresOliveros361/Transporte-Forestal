CREATE TABLE public.maestro_operacion (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 tipo text NOT NULL CHECK (tipo IN ('conductor','destino','finca','rodal','patio','especie')),
 nombre text NOT NULL CHECK (length(trim(nombre)) > 0),
 padre_id uuid REFERENCES public.maestro_operacion(id),
 cliente_id uuid REFERENCES public.clientes(id),
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.maestro_operacion TO authenticated;
GRANT ALL ON public.maestro_operacion TO service_role;
ALTER TABLE public.maestro_operacion ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth read master" ON public.maestro_operacion FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin insert master" ON public.maestro_operacion FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin update master" ON public.maestro_operacion FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE UNIQUE INDEX maestro_operacion_nombre_unique ON public.maestro_operacion(tipo, lower(trim(nombre)), coalesce(padre_id, '00000000-0000-0000-0000-000000000000'::uuid), coalesce(cliente_id, '00000000-0000-0000-0000-000000000000'::uuid));
ALTER TABLE public.vehiculos ADD COLUMN conductor_id uuid REFERENCES public.maestro_operacion(id);
ALTER TABLE public.despachos ADD COLUMN destino text;
ALTER TABLE public.despachos ADD COLUMN pedido_adicional text;
ALTER TABLE public.despachos ADD COLUMN patio text;
INSERT INTO public.maestro_operacion(tipo,nombre) SELECT 'especie', trim(especie) FROM public.productos WHERE trim(especie) <> '' GROUP BY trim(especie) ON CONFLICT DO NOTHING;
INSERT INTO public.maestro_operacion(tipo,nombre) SELECT 'patio', trim(patio) FROM public.inventario_patio WHERE trim(patio) <> '' GROUP BY trim(patio) ON CONFLICT DO NOTHING;
INSERT INTO public.maestro_operacion(tipo,nombre) SELECT 'conductor', trim(conductor) FROM public.despachos WHERE conductor IS NOT NULL AND trim(conductor) <> '' GROUP BY trim(conductor) ON CONFLICT DO NOTHING;
INSERT INTO public.maestro_operacion(tipo,nombre) SELECT 'finca', trim(finca) FROM public.despachos WHERE finca IS NOT NULL AND trim(finca) <> '' GROUP BY trim(finca) ON CONFLICT DO NOTHING;
INSERT INTO public.maestro_operacion(tipo,nombre,padre_id) SELECT 'rodal',trim(d.rodal),m.id FROM public.despachos d JOIN public.maestro_operacion m ON m.tipo='finca' AND lower(trim(m.nombre))=lower(trim(d.finca)) WHERE d.rodal IS NOT NULL AND trim(d.rodal) <> '' GROUP BY trim(d.rodal),m.id ON CONFLICT DO NOTHING;
INSERT INTO public.maestro_operacion(tipo,nombre,cliente_id) SELECT 'destino',trim(planta),id FROM public.clientes WHERE trim(planta) <> '' ON CONFLICT DO NOTHING;
UPDATE public.despachos d SET destino=c.planta FROM public.clientes c WHERE d.cliente_id=c.id AND d.destino IS NULL;
UPDATE public.despachos d SET patio=i.patio FROM public.inventario_patio i WHERE d.inventario_id=i.id AND d.patio IS NULL;
REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM authenticated;
DROP POLICY IF EXISTS "admin insert roles" ON public.user_roles;
DROP POLICY IF EXISTS "admin delete roles" ON public.user_roles;
COMMENT ON TABLE public.user_roles IS 'Roles managed only through the project, not through application users.';