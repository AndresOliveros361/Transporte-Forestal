
create type public.app_role as enum ('admin','supervisor','jefe_patio','transportador','cliente');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  nombre text,
  created_at timestamptz not null default now()
);
grant select, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select, insert, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_staff(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role in ('admin','supervisor','jefe_patio','transportador'))
$$;

create or replace function public.can_capture(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role in ('admin','supervisor','jefe_patio'))
$$;

create policy "own profile or admin read" on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "own profile update" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create policy "own roles or admin read" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));
create policy "admin insert roles" on public.user_roles for insert to authenticated
  with check (public.has_role(auth.uid(),'admin'));
create policy "admin delete roles" on public.user_roles for delete to authenticated
  using (public.has_role(auth.uid(),'admin'));

-- Catálogos
create table public.clientes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  planta text not null,
  ciudad text,
  created_at timestamptz not null default now()
);
create table public.unidades_manejo (
  id uuid primary key default gen_random_uuid(),
  codigo text not null unique,
  nombre text not null,
  area_ha numeric
);
create table public.productos (
  id uuid primary key default gen_random_uuid(),
  especie text not null,
  tipo text not null,
  unique (especie, tipo)
);
create table public.vehiculos (
  id uuid primary key default gen_random_uuid(),
  placa text not null unique,
  transportador text,
  capacidad_m3 numeric not null default 45 check (capacidad_m3 > 0 and capacidad_m3 <= 45)
);
create table public.metas_mensuales (
  mes date primary key,
  meta_m3 numeric not null check (meta_m3 > 0),
  viajes_dia integer not null default 12
);

create table public.cliente_usuarios (
  user_id uuid not null,
  cliente_id uuid not null references public.clientes(id) on delete cascade,
  primary key (user_id, cliente_id)
);

grant select on public.clientes, public.unidades_manejo, public.productos, public.vehiculos, public.metas_mensuales, public.cliente_usuarios to authenticated;
grant insert, update, delete on public.clientes, public.unidades_manejo, public.productos, public.vehiculos, public.metas_mensuales, public.cliente_usuarios to authenticated;
grant all on public.clientes, public.unidades_manejo, public.productos, public.vehiculos, public.metas_mensuales, public.cliente_usuarios to service_role;

alter table public.clientes enable row level security;
alter table public.unidades_manejo enable row level security;
alter table public.productos enable row level security;
alter table public.vehiculos enable row level security;
alter table public.metas_mensuales enable row level security;
alter table public.cliente_usuarios enable row level security;

create policy "auth read" on public.clientes for select to authenticated using (true);
create policy "auth read" on public.unidades_manejo for select to authenticated using (true);
create policy "auth read" on public.productos for select to authenticated using (true);
create policy "auth read" on public.vehiculos for select to authenticated using (true);
create policy "auth read" on public.metas_mensuales for select to authenticated using (true);
create policy "own or admin read" on public.cliente_usuarios for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(),'admin'));

create policy "admin write" on public.clientes for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.unidades_manejo for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.productos for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.vehiculos for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.metas_mensuales for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.cliente_usuarios for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- Inventario en patio
create table public.inventario_patio (
  id uuid primary key default gen_random_uuid(),
  patio text not null,
  unidad_id uuid not null references public.unidades_manejo(id),
  producto_id uuid not null references public.productos(id),
  volumen_m3 numeric not null check (volumen_m3 > 0),
  volumen_despachado_m3 numeric not null default 0,
  fecha_apilado date not null default current_date,
  observaciones text,
  created_by uuid,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.inventario_patio to authenticated;
grant all on public.inventario_patio to service_role;
alter table public.inventario_patio enable row level security;
create policy "staff read" on public.inventario_patio for select to authenticated using (public.is_staff(auth.uid()));
create policy "capture insert" on public.inventario_patio for insert to authenticated with check (public.can_capture(auth.uid()));
create policy "capture update" on public.inventario_patio for update to authenticated using (public.can_capture(auth.uid())) with check (public.can_capture(auth.uid()));

-- Despachos
create table public.despachos (
  id uuid primary key default gen_random_uuid(),
  remision text not null unique,
  vehiculo_id uuid not null references public.vehiculos(id),
  cliente_id uuid not null references public.clientes(id),
  producto_id uuid not null references public.productos(id),
  unidad_id uuid not null references public.unidades_manejo(id),
  inventario_id uuid references public.inventario_patio(id),
  volumen_m3 numeric not null check (volumen_m3 > 0 and volumen_m3 <= 45),
  fecha_salida timestamptz not null default now(),
  estado text not null default 'en_transito' check (estado in ('en_transito','entregado')),
  observaciones text,
  created_by uuid,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.despachos to authenticated;
grant all on public.despachos to service_role;
alter table public.despachos enable row level security;
create policy "staff or own client read" on public.despachos for select to authenticated
  using (public.is_staff(auth.uid()) or exists (select 1 from public.cliente_usuarios cu where cu.user_id = auth.uid() and cu.cliente_id = despachos.cliente_id));
create policy "capture insert" on public.despachos for insert to authenticated with check (public.can_capture(auth.uid()));
create policy "staff update" on public.despachos for update to authenticated using (public.is_staff(auth.uid())) with check (public.is_staff(auth.uid()));

create or replace function public.despacho_afecta_inventario()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.inventario_id is not null then
    update public.inventario_patio set volumen_despachado_m3 = volumen_despachado_m3 + new.volumen_m3 where id = new.inventario_id;
  end if;
  return new;
end $$;
create trigger trg_despacho_inventario after insert on public.despachos for each row execute function public.despacho_afecta_inventario();

-- Perfil y rol al registrarse: el primer usuario es admin, los demás supervisores
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, nombre) values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email,'@',1)));
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  else
    insert into public.user_roles (user_id, role) values (new.id, 'supervisor');
  end if;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

alter publication supabase_realtime add table public.despachos;
alter publication supabase_realtime add table public.inventario_patio;

-- Datos de ejemplo
insert into public.unidades_manejo (codigo, nombre, area_ha) values
 ('A','Unidad A - La Esperanza',120),('B','Unidad B - El Roble',95),('C','Unidad C - Alto Bonito',140),('D','Unidad D - San José',80);
insert into public.productos (especie, tipo) values
 ('P. patula','Aserrío'),('P. patula','Inmuniza'),('P. patula','Astillable'),
 ('P. maximinoi','Aserrío'),('P. maximinoi','Inmuniza'),('P. maximinoi','Astillable');
insert into public.clientes (nombre, planta, ciudad) values
 ('Maderas del Cauca','Planta Aserradero Norte','Popayán'),
 ('Inmunizadora Andina','Planta Inmunizado','Pereira'),
 ('Cartones Colombia','Planta Astillas','Yumbo');
insert into public.vehiculos (placa, transportador, capacidad_m3) values
 ('TKM-482','Transportes El Pino',45),('SXV-219','Transportes El Pino',45),('WGR-705','Logística Forestal',40),
 ('UPL-338','Logística Forestal',45),('THQ-561','Carga Andes',35),('SNB-904','Carga Andes',45);
insert into public.metas_mensuales (mes, meta_m3, viajes_dia) values
 (date_trunc('month', current_date)::date, 12000, 12);

insert into public.inventario_patio (patio, unidad_id, producto_id, volumen_m3, volumen_despachado_m3, fecha_apilado)
select v.patio, u.id, p.id, v.vol, v.desp, current_date - v.dias
from (values
 ('Patio 1','A','P. patula','Aserrío',320,180,3),
 ('Patio 1','A','P. patula','Astillable',210,40,14),
 ('Patio 2','B','P. maximinoi','Aserrío',275,90,8),
 ('Patio 2','B','P. maximinoi','Inmuniza',150,0,12),
 ('Patio 3','C','P. patula','Inmuniza',400,250,5),
 ('Patio 3','C','P. maximinoi','Astillable',190,0,18),
 ('Patio 4','D','P. patula','Aserrío',230,120,1)
) as v(patio, cod, esp, tipo, vol, desp, dias)
join public.unidades_manejo u on u.codigo = v.cod
join public.productos p on p.especie = v.esp and p.tipo = v.tipo;

insert into public.despachos (remision, vehiculo_id, cliente_id, producto_id, unidad_id, volumen_m3, fecha_salida, estado)
select 'REM-' || lpad(g::text, 5, '0'),
  (select id from public.vehiculos order by placa offset (g % 6) limit 1),
  (select id from public.clientes order by nombre offset (g % 3) limit 1),
  (select id from public.productos order by especie, tipo offset (g % 6) limit 1),
  (select id from public.unidades_manejo order by codigo offset (g % 4) limit 1),
  30 + (g % 15),
  date_trunc('month', now()) + ((g / 11) || ' days')::interval + ((6 + g % 11) || ' hours')::interval,
  case when g % 5 = 0 then 'en_transito' else 'entregado' end
from generate_series(1, 200) g
where date_trunc('month', now()) + ((g / 11) || ' days')::interval < now() - interval '1 day';

insert into public.despachos (remision, vehiculo_id, cliente_id, producto_id, unidad_id, volumen_m3, fecha_salida, estado)
select 'REM-H' || lpad(g::text, 3, '0'),
  (select id from public.vehiculos order by placa offset (g % 6) limit 1),
  (select id from public.clientes order by nombre offset (g % 3) limit 1),
  (select id from public.productos order by especie, tipo offset (g % 6) limit 1),
  (select id from public.unidades_manejo order by codigo offset (g % 4) limit 1),
  32 + g, date_trunc('day', now()) + ((6 + g) || ' hours')::interval,
  case when g < 3 then 'entregado' else 'en_transito' end
from generate_series(1, 5) g;
