ALTER TABLE public.pedidos ADD COLUMN descripcion_producto text, ADD COLUMN especificacion text, ADD COLUMN precio_m3 numeric CHECK (precio_m3 >= 0);
ALTER TABLE public.despachos ADD COLUMN linea_produccion text, ADD COLUMN conductor text, ADD COLUMN finca text, ADD COLUMN rodal text, ADD COLUMN descripcion_producto text;
COMMENT ON COLUMN public.pedidos.precio_m3 IS 'Precio por m3 en COP, independiente de tarifas históricas por tonelada.';
COMMENT ON COLUMN public.despachos.linea_produccion IS 'Línea operativa capturada por viaje, distinta de la unidad de manejo.';