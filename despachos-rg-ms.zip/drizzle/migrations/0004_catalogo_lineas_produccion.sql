CREATE TABLE public.lineas_produccion (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), nombre text NOT NULL UNIQUE CHECK (length(trim(nombre)) > 0), created_at timestamptz NOT NULL DEFAULT now());
GRANT SELECT, INSERT, UPDATE ON public.lineas_produccion TO authenticated;
GRANT ALL ON public.lineas_produccion TO service_role;
ALTER TABLE public.lineas_produccion ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth read lines" ON public.lineas_produccion FOR SELECT TO authenticated USING (true);
CREATE POLICY "admin insert lines" ON public.lineas_produccion FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin update lines" ON public.lineas_produccion FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
INSERT INTO public.lineas_produccion(nombre) SELECT DISTINCT upper(trim(linea_produccion)) FROM public.despachos WHERE linea_produccion IS NOT NULL AND length(trim(linea_produccion)) > 0 ON CONFLICT (nombre) DO NOTHING;
COMMENT ON TABLE public.lineas_produccion IS 'Catálogo para nuevas capturas; los nombres guardados en despachos históricos no se modifican al editar el catálogo.';