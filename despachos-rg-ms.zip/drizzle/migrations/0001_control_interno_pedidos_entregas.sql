CREATE TABLE public.pedidos (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 numero text NOT NULL UNIQUE,
 cliente_id uuid NOT NULL REFERENCES public.clientes(id),
 producto_id uuid NOT NULL REFERENCES public.productos(id),
 volumen_m3 numeric NOT NULL CHECK (volumen_m3 > 0),
 fecha_pedido date NOT NULL DEFAULT CURRENT_DATE,
 fecha_prevista date,
 observaciones text,
 created_by uuid,
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.pedidos TO authenticated;
GRANT ALL ON public.pedidos TO service_role;
ALTER TABLE public.pedidos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff read orders" ON public.pedidos FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
CREATE POLICY "capture insert orders" ON public.pedidos FOR INSERT TO authenticated WITH CHECK (public.can_capture(auth.uid()));
CREATE POLICY "capture update orders" ON public.pedidos FOR UPDATE TO authenticated USING (public.can_capture(auth.uid())) WITH CHECK (public.can_capture(auth.uid()));
ALTER TABLE public.despachos ADD COLUMN pedido_id uuid REFERENCES public.pedidos(id), ADD COLUMN fecha_entrega timestamptz;
CREATE INDEX despachos_pedido_idx ON public.despachos(pedido_id);
CREATE INDEX pedidos_cliente_idx ON public.pedidos(cliente_id);
DROP POLICY "staff or own client read" ON public.despachos;
CREATE POLICY "staff read dispatches" ON public.despachos FOR SELECT TO authenticated USING (public.is_staff(auth.uid()));
COMMENT ON TABLE public.cliente_usuarios IS 'DEPRECATED: the client portal is now internal order and delivery control; client-account mappings no longer grant dispatch access.';
CREATE OR REPLACE FUNCTION public.validar_pedido_despacho() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF NEW.pedido_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM public.pedidos p WHERE p.id=NEW.pedido_id AND p.cliente_id=NEW.cliente_id AND p.producto_id=NEW.producto_id) THEN
  RAISE EXCEPTION 'El pedido debe corresponder al mismo cliente y producto del despacho.';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER validar_pedido_despacho BEFORE INSERT OR UPDATE ON public.despachos FOR EACH ROW EXECUTE FUNCTION public.validar_pedido_despacho();
CREATE OR REPLACE FUNCTION public.validar_cliente_producto_pedido() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF (NEW.cliente_id IS DISTINCT FROM OLD.cliente_id OR NEW.producto_id IS DISTINCT FROM OLD.producto_id) AND EXISTS (SELECT 1 FROM public.despachos d WHERE d.pedido_id=OLD.id) THEN
  RAISE EXCEPTION 'No se puede cambiar cliente o producto de un pedido con despachos vinculados.';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER validar_cliente_producto_pedido BEFORE UPDATE ON public.pedidos FOR EACH ROW EXECUTE FUNCTION public.validar_cliente_producto_pedido();