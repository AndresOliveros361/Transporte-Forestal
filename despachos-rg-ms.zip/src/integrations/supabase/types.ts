export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      cliente_usuarios: {
        Row: {
          cliente_id: string
          user_id: string
        }
        Insert: {
          cliente_id: string
          user_id: string
        }
        Update: {
          cliente_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "cliente_usuarios_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
        ]
      }
      clientes: {
        Row: {
          ciudad: string | null
          created_at: string
          id: string
          nombre: string
          planta: string
        }
        Insert: {
          ciudad?: string | null
          created_at?: string
          id?: string
          nombre: string
          planta: string
        }
        Update: {
          ciudad?: string | null
          created_at?: string
          id?: string
          nombre?: string
          planta?: string
        }
        Relationships: []
      }
      despachos: {
        Row: {
          cliente_id: string
          conductor: string | null
          created_at: string
          created_by: string | null
          descripcion_producto: string | null
          destino: string | null
          empresa: string | null
          estado: string
          fecha_entrega: string | null
          fecha_salida: string
          finca: string | null
          id: string
          inventario_id: string | null
          linea_produccion: string | null
          observaciones: string | null
          patio: string | null
          pedido_adicional: string | null
          pedido_id: string | null
          producto_id: string
          remision: string
          rodal: string | null
          unidad_id: string
          vehiculo_id: string
          volumen_m3: number
        }
        Insert: {
          cliente_id: string
          conductor?: string | null
          created_at?: string
          created_by?: string | null
          descripcion_producto?: string | null
          destino?: string | null
          empresa?: string | null
          estado?: string
          fecha_entrega?: string | null
          fecha_salida?: string
          finca?: string | null
          id?: string
          inventario_id?: string | null
          linea_produccion?: string | null
          observaciones?: string | null
          patio?: string | null
          pedido_adicional?: string | null
          pedido_id?: string | null
          producto_id: string
          remision: string
          rodal?: string | null
          unidad_id: string
          vehiculo_id: string
          volumen_m3: number
        }
        Update: {
          cliente_id?: string
          conductor?: string | null
          created_at?: string
          created_by?: string | null
          descripcion_producto?: string | null
          destino?: string | null
          empresa?: string | null
          estado?: string
          fecha_entrega?: string | null
          fecha_salida?: string
          finca?: string | null
          id?: string
          inventario_id?: string | null
          linea_produccion?: string | null
          observaciones?: string | null
          patio?: string | null
          pedido_adicional?: string | null
          pedido_id?: string | null
          producto_id?: string
          remision?: string
          rodal?: string | null
          unidad_id?: string
          vehiculo_id?: string
          volumen_m3?: number
        }
        Relationships: [
          {
            foreignKeyName: "despachos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "despachos_inventario_id_fkey"
            columns: ["inventario_id"]
            isOneToOne: false
            referencedRelation: "inventario_patio"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "despachos_pedido_id_fkey"
            columns: ["pedido_id"]
            isOneToOne: false
            referencedRelation: "pedidos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "despachos_producto_id_fkey"
            columns: ["producto_id"]
            isOneToOne: false
            referencedRelation: "productos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "despachos_unidad_id_fkey"
            columns: ["unidad_id"]
            isOneToOne: false
            referencedRelation: "unidades_manejo"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "despachos_vehiculo_id_fkey"
            columns: ["vehiculo_id"]
            isOneToOne: false
            referencedRelation: "vehiculos"
            referencedColumns: ["id"]
          },
        ]
      }
      inventario_patio: {
        Row: {
          created_at: string
          created_by: string | null
          fecha_apilado: string
          id: string
          observaciones: string | null
          patio: string
          producto_id: string
          unidad_id: string
          volumen_despachado_m3: number
          volumen_m3: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          fecha_apilado?: string
          id?: string
          observaciones?: string | null
          patio: string
          producto_id: string
          unidad_id: string
          volumen_despachado_m3?: number
          volumen_m3: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          fecha_apilado?: string
          id?: string
          observaciones?: string | null
          patio?: string
          producto_id?: string
          unidad_id?: string
          volumen_despachado_m3?: number
          volumen_m3?: number
        }
        Relationships: [
          {
            foreignKeyName: "inventario_patio_producto_id_fkey"
            columns: ["producto_id"]
            isOneToOne: false
            referencedRelation: "productos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "inventario_patio_unidad_id_fkey"
            columns: ["unidad_id"]
            isOneToOne: false
            referencedRelation: "unidades_manejo"
            referencedColumns: ["id"]
          },
        ]
      }
      lineas_produccion: {
        Row: {
          created_at: string
          id: string
          latitud: number | null
          longitud: number | null
          nombre: string
        }
        Insert: {
          created_at?: string
          id?: string
          latitud?: number | null
          longitud?: number | null
          nombre: string
        }
        Update: {
          created_at?: string
          id?: string
          latitud?: number | null
          longitud?: number | null
          nombre?: string
        }
        Relationships: []
      }
      maestro_operacion: {
        Row: {
          cliente_id: string | null
          created_at: string
          id: string
          nombre: string
          padre_id: string | null
          tipo: string
        }
        Insert: {
          cliente_id?: string | null
          created_at?: string
          id?: string
          nombre: string
          padre_id?: string | null
          tipo: string
        }
        Update: {
          cliente_id?: string | null
          created_at?: string
          id?: string
          nombre?: string
          padre_id?: string | null
          tipo?: string
        }
        Relationships: [
          {
            foreignKeyName: "maestro_operacion_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "maestro_operacion_padre_id_fkey"
            columns: ["padre_id"]
            isOneToOne: false
            referencedRelation: "maestro_operacion"
            referencedColumns: ["id"]
          },
        ]
      }
      metas_mensuales: {
        Row: {
          mes: string
          meta_m3: number
          viajes_dia: number
        }
        Insert: {
          mes: string
          meta_m3: number
          viajes_dia?: number
        }
        Update: {
          mes?: string
          meta_m3?: number
          viajes_dia?: number
        }
        Relationships: []
      }
      pedidos: {
        Row: {
          cliente_id: string
          created_at: string
          created_by: string | null
          descripcion_producto: string | null
          especificacion: string | null
          fecha_pedido: string
          fecha_prevista: string | null
          id: string
          numero: string
          observaciones: string | null
          precio_m3: number | null
          producto_id: string
          volumen_m3: number
        }
        Insert: {
          cliente_id: string
          created_at?: string
          created_by?: string | null
          descripcion_producto?: string | null
          especificacion?: string | null
          fecha_pedido?: string
          fecha_prevista?: string | null
          id?: string
          numero: string
          observaciones?: string | null
          precio_m3?: number | null
          producto_id: string
          volumen_m3: number
        }
        Update: {
          cliente_id?: string
          created_at?: string
          created_by?: string | null
          descripcion_producto?: string | null
          especificacion?: string | null
          fecha_pedido?: string
          fecha_prevista?: string | null
          id?: string
          numero?: string
          observaciones?: string | null
          precio_m3?: number | null
          producto_id?: string
          volumen_m3?: number
        }
        Relationships: [
          {
            foreignKeyName: "pedidos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pedidos_producto_id_fkey"
            columns: ["producto_id"]
            isOneToOne: false
            referencedRelation: "productos"
            referencedColumns: ["id"]
          },
        ]
      }
      productos: {
        Row: {
          dimension: string | null
          especie: string
          id: string
          tipo: string
        }
        Insert: {
          dimension?: string | null
          especie: string
          id?: string
          tipo: string
        }
        Update: {
          dimension?: string | null
          especie?: string
          id?: string
          tipo?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          nombre: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id: string
          nombre?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          nombre?: string | null
        }
        Relationships: []
      }
      unidades_manejo: {
        Row: {
          area_ha: number | null
          codigo: string
          id: string
          nombre: string
        }
        Insert: {
          area_ha?: number | null
          codigo: string
          id?: string
          nombre: string
        }
        Update: {
          area_ha?: number | null
          codigo?: string
          id?: string
          nombre?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehiculos: {
        Row: {
          capacidad_m3: number
          conductor_id: string | null
          id: string
          placa: string
          transportador: string | null
        }
        Insert: {
          capacidad_m3?: number
          conductor_id?: string | null
          id?: string
          placa: string
          transportador?: string | null
        }
        Update: {
          capacidad_m3?: number
          conductor_id?: string | null
          id?: string
          placa?: string
          transportador?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "vehiculos_conductor_id_fkey"
            columns: ["conductor_id"]
            isOneToOne: false
            referencedRelation: "maestro_operacion"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_capture: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role:
        | "admin"
        | "supervisor"
        | "jefe_patio"
        | "transportador"
        | "cliente"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "supervisor",
        "jefe_patio",
        "transportador",
        "cliente",
      ],
    },
  },
} as const
