import { createFileRoute, Link, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ClipboardList, LayoutDashboard, Building2, Settings, LogOut, Wifi, WifiOff, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { misRoles, usuarioActual, esStaff, puedeCapturar, ROL_LABEL } from "@/lib/session";
import { sincronizarCola, useCola } from "@/lib/offline";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const user = await usuarioActual();
    if (!user) throw redirect({ to: "/auth" });
    const roles = await misRoles(user.id);
    return { user, roles };
  },
  component: Layout,
});

function useEnLinea() {
  const [on, setOn] = useState(true);
  useEffect(() => {
    setOn(navigator.onLine);
    const a = () => setOn(true);
    const b = () => setOn(false);
    window.addEventListener("online", a);
    window.addEventListener("offline", b);
    return () => {
      window.removeEventListener("online", a);
      window.removeEventListener("offline", b);
    };
  }, []);
  return on;
}

function Layout() {
  const { user, roles } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const enLinea = useEnLinea();
  const cola = useCola();
  const [sync, setSync] = useState(false);

  async function sincronizar(silencioso = false) {
    setSync(true);
    const r = await sincronizarCola();
    setSync(false);
    if (r.enviados) toast.success(`${r.enviados} registro(s) enviados al servidor`);
    if (r.fallidos && !silencioso) toast.error(`${r.fallidos} registro(s) con error. Revisa Pendientes.`);
  }

  useEffect(() => {
    if (enLinea) sincronizar(true);
    const t = setInterval(() => navigator.onLine && sincronizarCola(), 30000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enLinea]);

  const nav = [
    puedeCapturar(roles) && { to: "/campo", label: "Campo", icon: ClipboardList },
    esStaff(roles) && { to: "/dashboard", label: "Tablero", icon: LayoutDashboard },
    esStaff(roles) && { to: "/portal", label: "Clientes y pedidos", icon: Building2 },
    roles.includes("admin") && { to: "/admin", label: "Ajustes", icon: Settings },
  ].filter(Boolean) as { to: string; label: string; icon: typeof Settings }[];

  async function salir() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-56">
      <aside className="fixed bottom-0 left-0 top-9 hidden w-56 flex-col bg-sidebar p-4 text-sidebar-foreground md:flex">
        <div className="flex items-center gap-2">
          <img src="/icon-192.png" alt="" width={32} height={32} className="h-8 w-8 rounded" />
          <span className="font-display text-lg font-bold uppercase">Despachos</span>
        </div>
        <nav className="mt-8 flex flex-1 flex-col gap-1">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="flex items-center gap-3 rounded-md px-3 py-2 text-sm hover:bg-sidebar-accent" activeProps={{ className: "bg-sidebar-accent text-sidebar-primary" }}>
              <n.icon className="h-4 w-4" /> {n.label}
            </Link>
          ))}
        </nav>
        <div className="text-xs opacity-70">
          <p className="truncate">{user.email}</p>
          <p>{roles.map((r) => ROL_LABEL[r]).join(", ") || "Sin rol"}</p>
        </div>
        <button onClick={salir} className="mt-3 flex items-center gap-2 text-sm opacity-80 hover:opacity-100">
          <LogOut className="h-4 w-4" /> Salir
        </button>
      </aside>

      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b bg-background/95 px-4 py-2.5 backdrop-blur">
        <div className={cn("flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium", enLinea ? "bg-success/15 text-success" : "bg-warning/25 text-warning-foreground")}>
          {enLinea ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
          {enLinea ? "En línea" : "Sin conexión — guardando en el teléfono"}
        </div>
        <div className="flex items-center gap-2">
          {cola.length > 0 && (
            <button onClick={() => sincronizar()} disabled={!enLinea || sync} className="flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground disabled:opacity-60">
              <RefreshCw className={cn("h-3.5 w-3.5", sync && "animate-spin")} /> {cola.length} pendiente(s)
            </button>
          )}
          <button onClick={salir} className="md:hidden" aria-label="Salir">
            <LogOut className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl p-4 md:p-8">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-20 flex border-t bg-sidebar text-sidebar-foreground md:hidden">
        {nav.map((n) => (
          <Link key={n.to} to={n.to} className="flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px]" activeProps={{ className: "text-sidebar-primary" }}>
            <n.icon className="h-5 w-5" /> {n.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
