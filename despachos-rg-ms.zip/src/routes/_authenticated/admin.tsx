import { createFileRoute, redirect } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MaestroOperacion } from "@/components/maestro-operacion";
import { AjustesOperacion } from "@/components/ajustes-operacion";

export const Route = createFileRoute("/_authenticated/admin")({
  beforeLoad: ({ context }) => {
    if (!context.roles.includes("admin")) throw redirect({ to: "/inicio" });
  },
  head: () => ({
    meta: [
      { title: "Ajustes — Despachos de Madera" },
      { name: "description", content: "Edición de pilas de patio, productos, líneas de producción, vehículos y metas." },
      { property: "og:title", content: "Ajustes" },
      { property: "og:description", content: "Administración de datos de patio, productos y líneas de producción." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});


function Admin() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold uppercase">Ajustes</h1>
      <MaestroOperacion />
      <AjustesOperacion />
      <Meta />
    </div>
  );
}

function Meta() {
  const mes = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10);
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["meta", mes], queryFn: async () => (await supabase.from("metas_mensuales").select("*").eq("mes", mes).maybeSingle()).data });
  const [m3, setM3] = useState("");
  const [viajes, setViajes] = useState("");
  async function guardar() {
    const { error } = await supabase.from("metas_mensuales").upsert({ mes, meta_m3: Number(m3 || data?.meta_m3), viajes_dia: Number(viajes || data?.viajes_dia || 12) });
    if (error) return void toast.error(error.message);
    toast.success("Meta guardada");
    qc.invalidateQueries({ queryKey: ["meta", mes] });
  }
  return (
    <section className="rounded-xl bg-card p-5 shadow-card">
      <h2 className="text-xl font-semibold uppercase">Meta del mes</h2>
      <div className="mt-3 grid gap-3 sm:grid-cols-3 sm:items-end">
        <div className="space-y-1.5"><Label>m³ programados</Label><Input inputMode="decimal" placeholder={String(data?.meta_m3 ?? "")} value={m3} onChange={(e) => setM3(e.target.value)} /></div>
        <div className="space-y-1.5"><Label>Viajes por día</Label><Input inputMode="numeric" placeholder={String(data?.viajes_dia ?? 12)} value={viajes} onChange={(e) => setViajes(e.target.value)} /></div>
        <Button onClick={guardar}>Guardar</Button>
      </div>
    </section>
  );
}

