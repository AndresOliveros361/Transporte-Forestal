import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Trash2, Truck, PackagePlus, ListChecks } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { agregarACola, cargarCatalogos, eliminarDeCola, sincronizarCola, useCola, type Catalogos } from "@/lib/offline";
import { nombreProducto, opcionesMaestro, referenciaPedido, PEDIDO_OTRO } from "@/lib/maestro";
import { diasApilado, generarRemision, validarVolumenDespacho, VOLUMEN_MAX_CAMION_M3, toneladasAM3, m3AToneladas } from "@/lib/reglas";

export const Route = createFileRoute("/_authenticated/campo")({
  head: () => ({
    meta: [
      { title: "Captura en campo — Despachos de Madera" },
      { name: "description", content: "Registra despachos y entradas a patio, con o sin señal." },
      { property: "og:title", content: "Captura en campo" },
      { property: "og:description", content: "Registro de despachos y patios sin conexión." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Campo,
});

const selectCls =
  "h-12 w-full rounded-md border border-input bg-card px-3 text-base focus:outline-none focus:ring-2 focus:ring-ring";

function Campo() {
  const { data: cat, isLoading, refetch } = useQuery({ queryKey: ["catalogos"], queryFn: cargarCatalogos, staleTime: 60_000 });
  const cola = useCola();

  if (isLoading || !cat)
    return <p className="text-muted-foreground">Cargando listas… (la primera vez se necesita señal)</p>;

  return (
    <div>
      <h1 className="text-3xl font-bold uppercase">Captura en campo</h1>
      <p className="text-sm text-muted-foreground">
        Listas actualizadas: {new Date(cat.actualizado).toLocaleString("es-CO")}
      </p>
      <Tabs defaultValue="despacho" className="mt-5">
        <TabsList className="grid h-12 w-full grid-cols-3">
          <TabsTrigger value="despacho" className="h-10 gap-1.5"><Truck className="h-4 w-4" />Despacho</TabsTrigger>
          <TabsTrigger value="patio" className="h-10 gap-1.5"><PackagePlus className="h-4 w-4" />Patio</TabsTrigger>
          <TabsTrigger value="pend" className="h-10 gap-1.5"><ListChecks className="h-4 w-4" />Pendientes {cola.length > 0 && `(${cola.length})`}</TabsTrigger>
        </TabsList>
        <TabsContent value="despacho"><FormDespacho cat={cat} onDone={() => refetch()} /></TabsContent>
        <TabsContent value="patio"><FormPatio cat={cat} onDone={() => refetch()} /></TabsContent>
        <TabsContent value="pend"><Pendientes /></TabsContent>
      </Tabs>
    </div>
  );
}

function useUserId() {
  const { user } = Route.useRouteContext();
  return user.id;
}

async function guardar(tipo: "despacho" | "inventario", datos: Record<string, unknown>, resumen: string) {
  agregarACola({ id: datos["id"] as string, tipo, datos, resumen });
  if (navigator.onLine) {
    const r = await sincronizarCola();
    if (r.enviados) return void toast.success("Guardado y enviado al servidor");
    if (r.fallidos) return void toast.error("No se pudo enviar. Quedó en Pendientes.");
  }
  toast.success("Guardado en el teléfono. Se enviará al tener señal.");
}

function FormDespacho({ cat, onDone }: { cat: Catalogos; onDone: () => void }) {
  const userId = useUserId();
  const [vehiculo, setVehiculo] = useState("");
  const [cliente, setCliente] = useState("");
  const [pedido, setPedido] = useState("");
  const [adicional, setAdicional] = useState("");
  const [destino, setDestino] = useState("");
  const [patio, setPatio] = useState("");
  const [filtroEspecie, setFiltroEspecie] = useState("");
  const [pila, setPila] = useState("");
  const [producto, setProducto] = useState("");
  const [unidad, setUnidad] = useState("");
  const [volumen, setVolumen] = useState("");
  const [medida, setMedida] = useState("m3");
  const [linea, setLinea] = useState("");
  const [conductor, setConductor] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [finca, setFinca] = useState("");
  const [rodal, setRodal] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [remision, setRemision] = useState(generarRemision());
  const [obs, setObs] = useState("");

  const maestro = cat.maestro ?? [];
  const fincaElegida = maestro.find(d => d.tipo === "finca" && d.nombre === finca);
  const destinos = opcionesMaestro(maestro, "destino", { cliente_id: cliente });
  const prod = (id: string) => cat.productos.find((p) => p.id === id);
  const und = (id: string) => cat.unidades.find((u) => u.id === id);
  const pilas = useMemo(
    () => cat.inventario.filter((i) => Number(i.volumen_m3) - Number(i.volumen_despachado_m3) > 0),
    [cat.inventario],
  );
  const veh = cat.vehiculos.find((v) => v.id === vehiculo);
  const especie = prod(producto)?.especie ?? "";
  const entrada = Number(volumen.replace(",", "."));
  const volumenM3 = medida === "t" ? toneladasAM3(entrada, especie) : entrada;
  const peso = volumenM3 === null ? null : m3AToneladas(volumenM3, especie);

  function elegirPila(id: string) {
    setPila(id);
    const p = cat.inventario.find((i) => i.id === id);
    if (p) {
      setPatio(p.patio);
      setFiltroEspecie("");
      setProducto(p.producto_id);
      setUnidad(p.unidad_id);
    }
  }

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    const vol = volumenM3;
    if (vol === null) return void toast.error("Selecciona una especie con factor de conversión conocido.");
    const err = validarVolumenDespacho(vol, veh ? Number(veh.capacidad_m3) : undefined);
    if (err) return void toast.error(err);
    if (!vehiculo || !cliente || !producto || !unidad) return void toast.error("Completa vehículo, cliente, producto y unidad.");
    const pedidoElegido = cat.pedidos?.find((p) => p.id === pedido);
    if (pedido === PEDIDO_OTRO && !adicional.trim()) return void toast.error("Describe la solicitud adicional del cliente.");
    if (pedido && pedido !== PEDIDO_OTRO && (!pedidoElegido || pedidoElegido.cliente_id !== cliente || pedidoElegido.producto_id !== producto)) return void toast.error("El pedido debe corresponder al cliente y producto elegidos.");
    const id = crypto.randomUUID();
    await guardar(
      "despacho",
      {
        id,
        remision,
        vehiculo_id: vehiculo,
        cliente_id: cliente,
        ...referenciaPedido(pedido, adicional),
        destino: destino.trim() || cat.clientes.find(c => c.id === cliente)?.planta || null,
        patio: patio.trim() || null,
        producto_id: producto,
        unidad_id: unidad,
        inventario_id: pila || null,
        volumen_m3: vol,
        linea_produccion: linea.trim() || null,
        conductor: conductor.trim() || null,
        empresa: empresa.trim() || null,
        finca: finca.trim() || null,
        rodal: rodal.trim() || null,
        descripcion_producto: descripcion.trim() || null,
        fecha_salida: new Date().toISOString(),
        observaciones: obs || null,
        created_by: userId,
      },
      `${veh?.placa} · ${empresa.trim() || "Sin empresa registrada"} · ${vol} m³ · ${remision}`,
    );
    setVehiculo("");
    setEmpresa("");
    setPila("");
    setVolumen("");
    setObs("");
    setRemision(generarRemision());
    onDone();
  }

  return (
    <form onSubmit={enviar} className="mt-4 grid gap-4 rounded-xl bg-card p-5 shadow-card md:grid-cols-2">
      <Fila label="Placa del vehículo">
        <select className={selectCls} value={vehiculo} onChange={(e) => { setVehiculo(e.target.value); const v = cat.vehiculos.find(v => v.id === e.target.value); setConductor(maestro.find(d => d.id === v?.conductor_id)?.nombre ?? ""); }}>
          <option value="">Seleccionar…</option>
          {cat.vehiculos.map((v) => (
            <option key={v.id} value={v.id}>{v.placa} — {v.transportador} ({v.capacidad_m3} m³)</option>
          ))}
        </select>
      </Fila>
      <Fila label="Cliente / planta destino">
        <select className={selectCls} value={cliente} onChange={(e) => { setCliente(e.target.value); setPedido(""); setAdicional(""); setDestino(cat.clientes.find(c => c.id === e.target.value)?.planta ?? ""); }}>
          <option value="">Seleccionar…</option>
          {cat.clientes.map((c) => <option key={c.id} value={c.id}>{c.nombre} — {c.planta}</option>)}
        </select>
      </Fila>
      <Fila label="Destino"><select aria-label="Destino" className={selectCls} value={destino} onChange={e => setDestino(e.target.value)}><option value="">Seleccionar…</option>{Array.from(new Set([cat.clientes.find(c => c.id === cliente)?.planta, ...destinos.map(d => d.nombre)].filter((d): d is string => Boolean(d)))).map(d => <option key={d}>{d}</option>)}</select></Fila>
      <Fila label="Transportador"><Input aria-label="Transportador" className="h-12" value={veh?.transportador ?? ""} readOnly /></Fila>
      <Fila label="Empresa"><Input aria-label="Empresa" className="h-12" value={empresa} onChange={e=>setEmpresa(e.target.value)} /></Fila>
      <Fila label="Pedido del cliente (opcional)" full>
        <select aria-label="Pedido del cliente" className={selectCls} value={pedido} onChange={(e) => { setPedido(e.target.value); const p = cat.pedidos?.find(p => p.id === e.target.value); if (p) { setProducto(p.producto_id); setFiltroEspecie(""); setDescripcion(p.descripcion_producto ?? ""); setPila(""); } }}>
          <option value="">Sin pedido asignado</option>
          <option value={PEDIDO_OTRO}>Otro · solicitud adicional</option>
          {(cat.pedidos ?? []).filter(p => p.cliente_id === cliente).map(p => <option key={p.id} value={p.id}>{p.numero} · {p.descripcion_producto ?? ""} · {p.volumen_m3} m³</option>)}
        </select>
      </Fila>
      {pedido === PEDIDO_OTRO && <Fila label="Solicitud adicional" full><Input aria-label="Solicitud adicional" required value={adicional} onChange={e => setAdicional(e.target.value)}/></Fila>}
      <Fila label="Patio de origen"><select aria-label="Patio de origen" className={selectCls} value={patio} onChange={e => {setPatio(e.target.value);setPila("");}}><option value="">Directo de bosque</option>{Array.from(new Set([...opcionesMaestro(maestro,"patio").map(d => d.nombre),...cat.inventario.map(i=>i.patio)])).map(d=><option key={d}>{d}</option>)}</select></Fila>
      <Fila label="Pila de patio (opcional)" full>
        <select className={selectCls} value={pila} onChange={(e) => elegirPila(e.target.value)}>
          <option value="">Sin pila / directo de bosque</option>
          {pilas.filter(i => !patio || i.patio === patio).map((i) => (
            <option key={i.id} value={i.id}>
              {i.patio} · Unidad {und(i.unidad_id)?.codigo} · {prod(i.producto_id)?.especie} {prod(i.producto_id)?.tipo} · saldo {Number(i.volumen_m3) - Number(i.volumen_despachado_m3)} m³ · {diasApilado(i.fecha_apilado)} días
            </option>
          ))}
        </select>
      </Fila>
      <Fila label="Especie"><select aria-label="Especie" className={selectCls} value={filtroEspecie} onChange={e => {setFiltroEspecie(e.target.value);setProducto("");setPila("");}}><option value="">Todas las especies</option>{Array.from(new Set(cat.productos.map(p=>p.especie))).map(d=><option key={d}>{d}</option>)}</select></Fila>
      <Fila label="Especie y producto">
        <select className={selectCls} value={producto} onChange={(e) => setProducto(e.target.value)}>
          <option value="">Seleccionar…</option>
          {cat.productos.filter(p => !filtroEspecie || p.especie === filtroEspecie).map((p) => <option key={p.id} value={p.id}>{nombreProducto(p)}</option>)}
        </select>
      </Fila>
      <Fila label="Unidad de manejo">
        <select className={selectCls} value={unidad} onChange={(e) => setUnidad(e.target.value)}>
          <option value="">Seleccionar…</option>
          {cat.unidades.map((u) => <option key={u.id} value={u.id}>{u.codigo} — {u.nombre}</option>)}
        </select>
      </Fila>
      <Fila label={`Volumen cargado (m³, máx. ${veh ? Math.min(Number(veh.capacidad_m3), VOLUMEN_MAX_CAMION_M3) : VOLUMEN_MAX_CAMION_M3})`}>
        <div className="flex gap-2"><Input aria-label="Cantidad cargada" inputMode="decimal" className="h-12 min-w-0 text-base" value={volumen} onChange={(e) => setVolumen(e.target.value)} placeholder="0" /><select aria-label="Unidad de cantidad cargada" className={`${selectCls} max-w-24`} value={medida} onChange={e=>{setMedida(e.target.value);setVolumen("");}}><option value="m3">m³</option><option value="t">t</option></select></div>
        {volumen && volumenM3 !== null && <p className="text-sm text-muted-foreground">{volumenM3.toLocaleString("es-CO",{maximumFractionDigits:2})} m³{peso !== null && ` · ${peso.toLocaleString("es-CO",{maximumFractionDigits:2})} t equivalentes`}</p>}
        <div className="mt-2 flex gap-2">
          {[25, 35, 40, 45].map((n) => (
            <Button key={n} type="button" variant="secondary" size="sm" onClick={() => {setMedida("m3");setVolumen(String(n));}}>{n} m³</Button>
          ))}
        </div>
      </Fila>
      <Fila label="Tiquete de remisión">
        <Input className="h-12 text-base font-mono" value={remision} onChange={(e) => setRemision(e.target.value)} />
      </Fila>
      <Fila label="Línea de producción"><Input aria-label="Línea de producción" list="lineas-produccion" className="h-12" value={linea} onChange={e=>setLinea(e.target.value)} placeholder="ST20 / Arriería" /><datalist id="lineas-produccion">{(cat.lineas ?? []).map(l=><option key={l.id} value={l.nombre}/>)}</datalist></Fila>
      <Fila label="Conductor"><Input aria-label="Conductor" list="maestro-conductores" className="h-12" value={conductor} onChange={e=>setConductor(e.target.value)} /></Fila>
      <datalist id="maestro-conductores">{opcionesMaestro(maestro,"conductor").map(d=><option key={d.id} value={d.nombre}/>)}</datalist>
      <Fila label="Finca"><select aria-label="Finca" className={selectCls} value={finca} onChange={e=>{setFinca(e.target.value);setRodal("");}}><option value="">Seleccionar…</option>{opcionesMaestro(maestro,"finca").map(d=><option key={d.id}>{d.nombre}</option>)}</select></Fila>
      <Fila label="Rodal"><select aria-label="Rodal" className={selectCls} value={rodal} onChange={e=>setRodal(e.target.value)}><option value="">Seleccionar…</option>{(fincaElegida ? opcionesMaestro(maestro,"rodal",{padre_id:fincaElegida.id}) : []).map(d=><option key={d.id}>{d.nombre}</option>)}</select></Fila>
      <Fila label="Descripción del producto" full><Input aria-label="Descripción del producto" className="h-12" value={descripcion} onChange={e=>setDescripcion(e.target.value)} placeholder="Aserrío 2,20 m / Estacón campesino" /></Fila>
      <Fila label="Observaciones" full>
        <Input className="h-12" value={obs} onChange={(e) => setObs(e.target.value)} />
      </Fila>
      <Button type="submit" size="xl" variant="accent" className="md:col-span-2">Registrar despacho</Button>
    </form>
  );
}

function FormPatio({ cat, onDone }: { cat: Catalogos; onDone: () => void }) {
  const userId = useUserId();
  const patios = Array.from(new Set([...opcionesMaestro(cat.maestro ?? [], "patio").map(d=>d.nombre), ...cat.inventario.map((i) => i.patio)]));
  const [patio, setPatio] = useState(patios[0] ?? "");
  const [unidad, setUnidad] = useState("");
  const [producto, setProducto] = useState("");
  const [volumen, setVolumen] = useState("");
  const [fecha, setFecha] = useState(new Date().toISOString().slice(0, 10));

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    const vol = Number(volumen.replace(",", "."));
    if (!(vol > 0)) return void toast.error("El volumen debe ser mayor a 0.");
    if (!patio || !unidad || !producto) return void toast.error("Elige patio, unidad y producto.");
    const id = crypto.randomUUID();
    await guardar(
      "inventario",
      { id, patio, unidad_id: unidad, producto_id: producto, volumen_m3: vol, fecha_apilado: fecha, created_by: userId },
      `${patio} · ${vol} m³ · entrada ${fecha}`,
    );
    setVolumen("");
    onDone();
  }

  return (
    <form onSubmit={enviar} className="mt-4 grid gap-4 rounded-xl bg-card p-5 shadow-card md:grid-cols-2">
      <Fila label="Patio">
        <select className={selectCls} value={patio} onChange={(e) => setPatio(e.target.value)}>
          <option value="">Seleccionar…</option>{patios.map((p) => <option key={p}>{p}</option>)}
        </select>
      </Fila>
      <Fila label="Fecha de apilado">
        <Input type="date" className="h-12 text-base" value={fecha} onChange={(e) => setFecha(e.target.value)} />
      </Fila>
      <Fila label="Unidad de manejo">
        <select className={selectCls} value={unidad} onChange={(e) => setUnidad(e.target.value)}>
          <option value="">Seleccionar…</option>
          {cat.unidades.map((u) => <option key={u.id} value={u.id}>{u.codigo} — {u.nombre}</option>)}
        </select>
      </Fila>
      <Fila label="Especie y producto">
        <select className={selectCls} value={producto} onChange={(e) => setProducto(e.target.value)}>
          <option value="">Seleccionar…</option>
          {cat.productos.map((p) => <option key={p.id} value={p.id}>{nombreProducto(p)}</option>)}
        </select>
      </Fila>
      <Fila label="Volumen estimado (m³)" full>
        <Input inputMode="decimal" className="h-12 text-base" value={volumen} onChange={(e) => setVolumen(e.target.value)} placeholder="0" />
      </Fila>
      <Button type="submit" size="xl" variant="accent" className="md:col-span-2">Registrar entrada a patio</Button>
    </form>
  );
}

function Pendientes() {
  const cola = useCola();
  if (!cola.length)
    return <p className="mt-6 rounded-xl bg-card p-6 text-center text-muted-foreground shadow-card">Todo está enviado. No hay registros pendientes.</p>;
  return (
    <ul className="mt-4 space-y-2">
      {cola.map((r) => (
        <li key={r.id} className="flex items-start justify-between gap-3 rounded-lg bg-card p-4 shadow-card">
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground">{r.tipo === "despacho" ? "Despacho" : "Entrada a patio"} · {new Date(r.creado).toLocaleString("es-CO")}</p>
            <p className="font-medium">{r.resumen}</p>
            {r.error && <p className="mt-1 text-sm text-destructive">Error: {r.error}</p>}
          </div>
          <Button variant="ghost" size="icon" aria-label="Eliminar" onClick={() => confirm("¿Eliminar este registro sin enviarlo?") && eliminarDeCola(r.id)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </li>
      ))}
    </ul>
  );
}

function Fila({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? "space-y-1.5 md:col-span-2" : "space-y-1.5"}>
      <Label className="text-sm font-semibold">{label}</Label>
      {children}
    </div>
  );
}
