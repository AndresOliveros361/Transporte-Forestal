import { createFileRoute, redirect } from "@tanstack/react-router";
import { useSuspenseQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Pencil, Check, Truck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { esStaff, puedeCapturar } from "@/lib/session";
import { controlOptions, type Pedido, type Viaje } from "@/lib/pedidos";
import { nombreProducto as etiquetaProducto } from "@/lib/maestro";
import { avancePedido } from "@/lib/avance-pedidos";
import { resumenDespachos, frecuenciaConductores } from "@/lib/resumen-operacion";
import { m3AToneladas, toneladasAM3 } from "@/lib/reglas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export const Route = createFileRoute("/_authenticated/portal")({
  beforeLoad: ({ context }) => { if (!esStaff(context.roles)) throw redirect({ to: "/inicio" }); },
  loader: ({ context }) => context.queryClient.ensureQueryData(controlOptions),
  head: () => ({ meta: [
    { title: "Clientes y pedidos — Despachos de Madera" },
    { name: "description", content: "Control interno de pedidos, camiones despachados y entregas por cliente." },
    { property: "og:title", content: "Clientes y pedidos — Despachos de Madera" },
    { property: "og:description", content: "Avance de despacho y recepción de cada pedido." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: ControlClientes,
});
const fmt = (n: number) => n.toLocaleString("es-CO", { maximumFractionDigits: 2 });
const selectCls = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";

function ControlClientes() {
  const { data } = useSuspenseQuery(controlOptions);
  const { roles, user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [cliente, setCliente] = useState("");
  const [mes, setMes] = useState("");
  const [estado, setEstado] = useState("");
  const [seleccion, setSeleccion] = useState("");
  const [editor, setEditor] = useState<Pedido | "nuevo" | null>(null);
  const [busy, setBusy] = useState(false);
  const editable = puedeCapturar(roles);
  const refresh = () => Promise.all([qc.invalidateQueries({ queryKey: ["control-clientes"] }), qc.invalidateQueries({ queryKey: ["catalogos"] }), qc.invalidateQueries({ queryKey: ["despachos-mes"] })]);
  const pedidos = data.pedidos.filter(p => (!cliente || p.cliente_id === cliente) && (!mes || p.fecha_pedido.startsWith(mes)) && (!estado || avancePedido(Number(p.volumen_m3), data.viajes.filter(v => v.pedido_id === p.id)).estado === estado));
  const viajesCliente = data.viajes.filter(v => (!cliente || v.cliente_id === cliente) && (!mes || new Date(v.fecha_salida).toLocaleDateString("en-CA", { timeZone: "America/Bogota" }).startsWith(mes)));
  const sinPedido = viajesCliente.filter(v => !v.pedido_id);
  const pedidoActual = pedidos.find(p => p.id === seleccion);
  const viajes = pedidoActual ? data.viajes.filter(v => v.pedido_id === pedidoActual.id) : sinPedido;
  const nombreCliente = (id: string) => { const c = data.clientes.find(c => c.id === id); return c ? `${c.nombre} · ${c.planta}` : "—"; };
  const nombreProducto = (id: string) => { const p = data.productos.find(p => p.id === id); return p ? etiquetaProducto(p) : "—"; };
  const totales = pedidos.reduce((s,p)=>{const a=avancePedido(Number(p.volumen_m3),data.viajes.filter(v=>v.pedido_id===p.id));const precio=Number(p.precio_m3 ?? 0);return {solicitado:s.solicitado+Number(p.volumen_m3),pendiente:s.pendiente+a.porDespachar,exceso:s.exceso+a.excesoDespachado,valorPedido:s.valorPedido+Number(p.volumen_m3)*precio,valorDespacho:s.valorDespacho+a.despachado*precio,valorPendiente:s.valorPendiente+a.porDespachar*precio,valorExceso:s.valorExceso+a.excesoDespachado*precio};},{solicitado:0,pendiente:0,exceso:0,valorPedido:0,valorDespacho:0,valorPendiente:0,valorExceso:0});

  async function actualizar(v: Viaje, values: { pedido_id?: string | null; estado?: string; fecha_entrega?: string }) {
    setBusy(true);
    try {
      const { data: saved, error } = await supabase.from("despachos").update(values).eq("id", v.id).select("id").single();
      if (error || !saved) throw error ?? new Error("No se pudo actualizar el despacho");
      await refresh(); toast.success(values.estado ? "Entrega confirmada" : "Despacho vinculado al pedido");
    } catch (e) { toast.error(e instanceof Error ? e.message : "No se pudo guardar el cambio"); }
    finally { setBusy(false); }
  }

  return <div className="space-y-6">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <h1 className="text-3xl font-bold uppercase">Clientes y pedidos</h1>
      {editable && <Button onClick={() => setEditor("nuevo")}><Plus className="mr-2 h-4 w-4" />Nuevo pedido</Button>}
    </div>
    <div className="grid grid-cols-2 gap-4 border-y py-5 lg:grid-cols-4">
      {[ ["Pedidos", pedidos.length], ["Despachado · m³", viajesCliente.reduce((s,v)=>s+Number(v.volumen_m3),0)], ["Entregado · m³", viajesCliente.filter(v=>v.estado==="entregado").reduce((s,v)=>s+Number(v.volumen_m3),0)], ["Camiones en tránsito", viajesCliente.filter(v=>v.estado==="en_transito").length] ].map(([label, value]) => <div key={label}><p className="text-xs uppercase text-muted-foreground">{label}</p><p className="mt-1 font-display text-3xl font-bold">{fmt(Number(value))}</p></div>)}
    </div>
    <div className="flex flex-wrap gap-3">
      <Input aria-label="Mes de control" type="month" className="w-48" value={mes} onChange={e=>{setMes(e.target.value);setSeleccion("");}} />
      <select aria-label="Filtrar cliente" className={`${selectCls} max-w-sm`} value={cliente} onChange={e=>{setCliente(e.target.value);setSeleccion("");}}><option value="">Todos los clientes</option>{data.clientes.map(c=><option key={c.id} value={c.id}>{c.nombre} · {c.planta}</option>)}</select>
      <select aria-label="Filtrar estado" className={`${selectCls} max-w-48`} value={estado} onChange={e=>{setEstado(e.target.value);setSeleccion("");}}><option value="">Todos los estados</option>{["Pendiente","En entrega","Entregado"].map(s=><option key={s}>{s}</option>)}</select>
      <Button variant="outline" onClick={()=>refresh()}>Actualizar</Button>
      {mes && <Button variant="ghost" onClick={()=>{setMes("");setSeleccion("");}}>Todos los meses</Button>}
    </div>
    <Tabs defaultValue="pedidos"><TabsList className="h-auto flex-wrap justify-start"><TabsTrigger value="pedidos">Pedidos y entregas</TabsTrigger><TabsTrigger value="operacion">Empresas, líneas y conductores</TabsTrigger><TabsTrigger value="valores">Valores</TabsTrigger></TabsList>
    <TabsContent value="operacion"><ResumenOperacion viajes={viajesCliente} productos={data.productos}/></TabsContent>
    <TabsContent value="valores"><div className="grid grid-cols-2 gap-5 border-y py-5 lg:grid-cols-4">{[["Valor solicitado",totales.valorPedido],["Valor despachado",totales.valorDespacho],["Valor por despachar",totales.valorPendiente],["Valor excedente",totales.valorExceso]].map(([l,v])=><div key={l}><p className="text-xs uppercase text-muted-foreground">{l} · COP</p><p className="mt-2 font-display text-2xl font-bold">{Number(v).toLocaleString("es-CO",{style:"currency",currency:"COP",maximumFractionDigits:0})}</p></div>)}</div><p className="py-3 text-sm text-muted-foreground">{pedidos.filter(p=>p.precio_m3===null).length} pedidos sin precio · Valores calculados con los camiones vinculados, no pagos ni facturación.</p></TabsContent>
    <TabsContent value="pedidos" className="space-y-5">
    <div className="grid grid-cols-3 gap-4 border-b py-4">{[["Solicitado",totales.solicitado],["Por despachar",totales.pendiente],["Despachado de más",totales.exceso]].map(([l,v])=><div key={l}><p className="text-xs uppercase text-muted-foreground">{l}</p><p className="mt-1 font-display text-2xl font-bold">{fmt(Number(v))} m³</p></div>)}</div>
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-muted-foreground"><tr>{["Pedido / cliente","Producto / especificación","Prevista","Pedido","Despachado","Pendiente / exceso","Entregado","Avance",""].map((h,i)=><th key={i} className="p-3 whitespace-nowrap">{h}</th>)}</tr></thead>
      <tbody className="divide-y">{pedidos.map(p=>{
        const a=avancePedido(Number(p.volumen_m3),data.viajes.filter(v=>v.pedido_id===p.id));
        return <tr key={p.id} className={seleccion===p.id ? "bg-muted" : ""}>
          <td className="p-3"><Button variant="link" className="h-auto p-0" onClick={()=>setSeleccion(p.id)}>{p.numero}</Button><p className="mt-1 min-w-40 text-xs text-muted-foreground">{nombreCliente(p.cliente_id)}</p></td>
          <td className="min-w-48 p-3">{p.descripcion_producto || nombreProducto(p.producto_id)}<p className="text-xs text-muted-foreground">{p.especificacion}</p></td><td className="p-3 whitespace-nowrap">{p.fecha_prevista ?? "—"}</td>
          <td className="p-3 whitespace-nowrap">{fmt(Number(p.volumen_m3))} m³</td><td className="p-3 whitespace-nowrap">{fmt(a.despachado)} m³<p className="text-xs text-muted-foreground">{a.viajes} camiones</p></td><td className="p-3 whitespace-nowrap">{fmt(a.porDespachar)} m³ pendientes{a.excesoDespachado>0 && <p className="text-warning">{fmt(a.excesoDespachado)} m³ de más</p>}</td><td className="p-3 whitespace-nowrap">{fmt(a.entregado)} m³</td>
          <td className="min-w-36 p-3"><p className="mb-2 text-xs">{a.estado} · {fmt(a.porcentaje)}%</p><Progress value={a.porcentaje}/></td>
          <td className="p-3">{editable && <Button variant="ghost" size="icon" aria-label={`Editar pedido ${p.numero}`} onClick={()=>setEditor(p)}><Pencil className="h-4 w-4"/></Button>}</td>
        </tr>;
      })}{!pedidos.length && <tr><td colSpan={9} className="py-8 text-center text-muted-foreground">No hay pedidos registrados con estos filtros.</td></tr>}</tbody></table>
    </div>
    <section className="space-y-4 border-t pt-5">
      <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold uppercase">{pedidoActual ? `Camiones · ${pedidoActual.numero}` : `Despachos sin pedido (${sinPedido.length})`}</h2>{pedidoActual && <Button variant="outline" onClick={()=>setSeleccion("")}>Ver sin pedido</Button>}</div>
      {pedidoActual && (()=>{const a=avancePedido(Number(pedidoActual.volumen_m3),viajes);return <p className="text-sm text-muted-foreground">Por despachar: {fmt(a.porDespachar)} m³ · En tránsito: {fmt(a.enTransito)} m³ · Por entregar: {fmt(a.porEntregar)} m³{pedidoActual.observaciones && ` · ${pedidoActual.observaciones}`}</p>;})()}
      <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-muted-foreground"><tr>{["Remisión / salida","Placa / conductor","Empresa","Cliente","Línea / origen","Producto","Volumen","Entrega","Pedido"].map(h=><th key={h} className="p-3">{h}</th>)}</tr></thead><tbody className="divide-y">{viajes.map(v=><tr key={v.id}>
        <td className="p-3 font-mono">{v.remision}<p className="mt-1 whitespace-nowrap font-sans text-xs text-muted-foreground">{new Date(v.fecha_salida).toLocaleDateString("es-CO")}</p></td><td className="p-3 font-mono">{v.vehiculos?.placa}<p className="font-sans text-xs text-muted-foreground">{v.conductor || "—"}</p></td><td className="p-3">{v.empresa || "Sin empresa registrada"}</td><td className="p-3">{nombreCliente(v.cliente_id)}<p className="text-xs text-muted-foreground">{v.destino}</p></td><td className="p-3">{v.linea_produccion || "Sin línea"}<p className="text-xs text-muted-foreground">{[v.finca,v.rodal,v.patio].filter(Boolean).join(" · ")}</p></td><td className="min-w-40 p-3">{v.descripcion_producto || nombreProducto(v.producto_id)}{v.pedido_adicional && <p className="text-xs text-warning">Otro: {v.pedido_adicional}</p>}</td><td className="p-3 whitespace-nowrap">{fmt(Number(v.volumen_m3))} m³</td>
        <td className="p-3">{v.estado==="entregado" ? <span className="text-success">Entregado{v.fecha_entrega && <span className="block text-xs">{new Date(v.fecha_entrega).toLocaleDateString("es-CO")}</span>}</span> : <Button variant="outline" size="sm" disabled={busy} onClick={()=>{if(window.confirm(`¿Confirmar la recepción de ${v.remision}?`)) actualizar(v,{estado:"entregado",fecha_entrega:new Date().toISOString()});}}><Check className="mr-1 h-4 w-4"/>Confirmar entrega</Button>}</td>
        <td className="min-w-48 p-3">{editable ? <select aria-label={`Pedido de ${v.remision}`} className={selectCls} value={v.pedido_id ?? ""} disabled={busy} onChange={e=>actualizar(v,{pedido_id:e.target.value || null})}><option value="">Sin pedido</option>{data.pedidos.filter(p=>p.cliente_id===v.cliente_id && p.producto_id===v.producto_id).map(p=><option key={p.id} value={p.id}>{p.numero}</option>)}</select> : data.pedidos.find(p=>p.id===v.pedido_id)?.numero ?? "Sin pedido"}</td>
      </tr>)}{!viajes.length && <tr><td colSpan={9} className="py-8 text-center text-muted-foreground"><Truck className="mx-auto mb-2 h-6 w-6"/>No hay camiones en esta lista.</td></tr>}</tbody></table></div>
    </section>
    </TabsContent></Tabs>
    <Dialog open={editor!==null} onOpenChange={open=>{if(!open)setEditor(null);}}><DialogContent className="max-h-[90vh] overflow-y-auto" aria-describedby={undefined}><DialogHeader><DialogTitle>{editor==="nuevo" ? "Nuevo pedido" : "Editar pedido"}</DialogTitle></DialogHeader>{editor && <EditorPedido key={editor==="nuevo" ? "nuevo" : editor.id} pedido={editor==="nuevo" ? null : editor} clientes={data.clientes} productos={data.productos} bloqueado={editor!=="nuevo" && data.viajes.some(v=>v.pedido_id===editor.id)} userId={user.id} onDone={async()=>{await refresh();setEditor(null);}}/>}</DialogContent></Dialog>
  </div>;
}

function ResumenOperacion({viajes,productos}: {viajes:Viaje[];productos:{id:string;especie:string;tipo:string;dimension?:string|null}[]}) {
  return <div className="space-y-6 py-4">{(["empresa","linea"] as const).map(tipo=><section key={tipo}><h2 className="text-xl font-semibold uppercase">{tipo==="empresa" ? "Productividad · despachos por empresa" : "Despacho por línea y producto"}</h2><div className="mt-3 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-muted-foreground"><tr>{[tipo==="empresa" ? "Empresa" : "Línea",...(tipo==="linea" ? ["Producto"] : []),"Viajes","m³ despachados","t equivalentes"].map(h=><th className="p-3" key={h}>{h}</th>)}</tr></thead><tbody className="divide-y">{resumenDespachos(viajes,productos,tipo).map(g=><tr key={JSON.stringify([g.nombre,g.producto])}><td className="p-3">{g.nombre}</td>{tipo==="linea" && <td className="p-3">{g.producto}</td>}<td className="p-3">{g.viajes}</td><td className="p-3">{fmt(g.m3)}</td><td className="p-3">{g.sinFactor ? "Sin factor para todos los viajes" : fmt(g.ton)}</td></tr>)}{!viajes.length && <tr><td colSpan={tipo==="linea" ? 5 : 4} className="py-6 text-center text-muted-foreground">Sin despachos para este período.</td></tr>}</tbody></table></div></section>)}
    <section><h2 className="text-xl font-semibold uppercase">Frecuencia de conductores · informativo</h2><div className="mt-3 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-muted-foreground"><tr>{["Conductor","Viajes","Días con viajes","Viajes / día activo"].map(h=><th key={h} className="p-3">{h}</th>)}</tr></thead><tbody className="divide-y">{frecuenciaConductores(viajes).map(g=><tr key={g.nombre}><td className="p-3">{g.nombre}</td><td className="p-3">{g.viajes}</td><td className="p-3">{g.diasActivos}</td><td className="p-3">{fmt(g.viajesPorDiaActivo)}</td></tr>)}{!viajes.length && <tr><td colSpan={4} className="py-6 text-center text-muted-foreground">Sin despachos para este período.</td></tr>}</tbody></table></div></section>
  </div>;
}

function EditorPedido({pedido,clientes,productos,bloqueado,userId,onDone}: {pedido:Pedido|null;clientes:{id:string;nombre:string;planta:string}[];productos:{id:string;especie:string;tipo:string;dimension?:string|null}[];bloqueado:boolean;userId:string;onDone:()=>Promise<void>}) {
  const [busy,setBusy]=useState(false);
  const [producto,setProducto]=useState(pedido?.producto_id ?? "");
  const [unidad,setUnidad]=useState("m3");
  async function guardar(e:React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f=new FormData(e.currentTarget);
    const cantidad=Number(String(f.get("volumen")).replace(",","."));
    const vol=unidad==="t" ? toneladasAM3(cantidad,productos.find(p=>p.id===producto)?.especie ?? "") : cantidad;
    if(vol===null) return void toast.error("Selecciona una especie con conversión conocida.");
    if(!Number.isFinite(vol)||vol<=0) return void toast.error("El volumen pedido debe ser mayor a cero.");
    const precioTexto=String(f.get("precio") ?? "").trim();const precio=precioTexto ? Number(precioTexto.replace(",",".")) : null;
    if(precio!==null && (!Number.isFinite(precio)||precio<0)) return void toast.error("El precio debe ser cero o mayor.");
    const values={numero:String(f.get("numero")).trim(),cliente_id:String(f.get("cliente")),producto_id:producto,volumen_m3:vol,fecha_pedido:String(f.get("fecha")),fecha_prevista:String(f.get("prevista"))||null,observaciones:String(f.get("obs"))||null,descripcion_producto:String(f.get("descripcion") ?? "").trim()||null,especificacion:String(f.get("especificacion") ?? "").trim()||null,precio_m3:precio};
    setBusy(true);
    try { const result=pedido ? await supabase.from("pedidos").update({...values,...(bloqueado ? {cliente_id:pedido.cliente_id,producto_id:pedido.producto_id} : {})}).eq("id",pedido.id).select("id").single() : await supabase.from("pedidos").insert({...values,created_by:userId}).select("id").single(); if(result.error) throw result.error; await onDone();toast.success("Pedido guardado"); }
    catch {toast.error("No se pudo guardar. Revisa la conexión y que el número de pedido no esté repetido.");} finally{setBusy(false);}
  }
  return <form onSubmit={guardar} className="grid gap-4">
    <div><Label htmlFor="numero">Número de pedido</Label><Input id="numero" name="numero" required defaultValue={pedido?.numero}/></div>
    <div><Label htmlFor="cliente-pedido">Cliente / planta</Label><select id="cliente-pedido" name="cliente" required disabled={bloqueado} className={selectCls} defaultValue={pedido?.cliente_id ?? ""}><option value="">Seleccionar…</option>{clientes.map(c=><option key={c.id} value={c.id}>{c.nombre} · {c.planta}</option>)}</select></div>
    <div><Label htmlFor="producto-pedido">Producto</Label><select id="producto-pedido" name="producto" required disabled={bloqueado} className={selectCls} value={producto} onChange={e=>setProducto(e.target.value)}><option value="">Seleccionar…</option>{productos.map(p=><option key={p.id} value={p.id}>{etiquetaProducto(p)}</option>)}</select></div>
    <div><Label htmlFor="descripcion-pedido">Descripción del producto</Label><Input id="descripcion-pedido" name="descripcion" defaultValue={pedido?.descripcion_producto ?? ""} placeholder="Aserrío 2,20 m"/></div>
    <div><Label htmlFor="especificacion">Especificación</Label><Input id="especificacion" name="especificacion" defaultValue={pedido?.especificacion ?? ""} placeholder="Diámetro, largo o calidad"/></div>
    <div><Label htmlFor="volumen-pedido">Cantidad pedida</Label><div className="flex gap-2"><Input key={unidad} id="volumen-pedido" name="volumen" inputMode="decimal" required defaultValue={unidad==="m3" ? pedido?.volumen_m3 : undefined}/><select aria-label="Unidad del pedido" className={`${selectCls} max-w-24`} value={unidad} onChange={e=>setUnidad(e.target.value)}><option value="m3">m³</option><option value="t">t</option></select></div></div>
    <div><Label htmlFor="precio-pedido">Precio por m³ (COP)</Label><Input id="precio-pedido" name="precio" inputMode="decimal" defaultValue={pedido?.precio_m3 ?? ""}/></div>
    <div className="grid grid-cols-2 gap-3"><div><Label htmlFor="fecha-pedido">Fecha del pedido</Label><Input id="fecha-pedido" name="fecha" type="date" required defaultValue={pedido?.fecha_pedido ?? new Date().toLocaleDateString("en-CA")}/></div><div><Label htmlFor="prevista">Entrega prevista</Label><Input id="prevista" name="prevista" type="date" defaultValue={pedido?.fecha_prevista ?? ""}/></div></div>
    <div><Label htmlFor="obs-pedido">Observaciones</Label><Input id="obs-pedido" name="obs" defaultValue={pedido?.observaciones ?? ""}/></div>
    <Button disabled={busy} type="submit">{busy ? "Guardando…" : "Guardar pedido"}</Button>
  </form>;
}
