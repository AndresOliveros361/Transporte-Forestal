import { createFileRoute, redirect } from "@tanstack/react-router";
import { esStaff, puedeCapturar } from "@/lib/session";

// Envía a cada persona a su pantalla principal según su rol.
export const Route = createFileRoute("/_authenticated/inicio")({
  head: () => ({ meta: [
    { title: "Inicio de operación — Despachos de Madera" },
    { name: "description", content: "Acceso a captura de madera, pedidos y tablero según el rol del equipo." },
    { property: "og:title", content: "Inicio de operación — Despachos de Madera" },
    { property: "og:description", content: "Entrada a la operación interna de despachos y patios." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  beforeLoad: ({ context }) => {
    const roles = context.roles;
    if (puedeCapturar(roles) && !roles.includes("admin")) throw redirect({ to: "/campo" });
    if (esStaff(roles)) throw redirect({ to: "/dashboard" });
    throw redirect({ to: "/" });
  },
});
