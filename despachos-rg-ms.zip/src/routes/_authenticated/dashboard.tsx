import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine } from "recharts";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { despachosDesde, useTiempoReal } from "@/lib/datos";
import { diasApilado, semaforoPatio, DIAS_ALERTA_PATIO } from "@/lib/reglas";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Tablero de control — Despachos de Madera" },
      { name: "description", content: "Avance volumétrico, camiones del día y semáforo de patios." },
      { property: "og:title", content: "Tablero de control" },
      { property: "og:description", content: "Metas de m³, logística diaria y alertas de permanencia." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

const fmt = (n: number) => n.toLocaleString("es-CO", { maximumFractionDigits: 0 });

function Dashboard() {
  const inicioMes = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const mesKey = inicioMes.toISOString().slice(0, 10);
  const qc = useQueryClient();
  useTiempoReal([["despachos-mes"], ["inventario"]]);

  const desp = useQuery({ queryKey: ["despachos-mes"], queryFn: () => despachosDesde(inicioMes) });
  const meta = useQuery({
    queryKey: ["meta", mesKey],
    queryFn: async () => (await supabase.from("metas_mensuales").select("*").eq("mes", mesKey).maybeSingle()).data,
  });
  const inv = useQuery({
    queryKey: ["inventario"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inventario_patio")
        .select("id, patio, volumen_m3, volumen_despachado_m3, fecha_apilado, unidades_manejo(codigo), productos(especie, tipo)")
        .order("fecha_apilado");
      if (error) throw error;
      return data;
    },
  });

  const lista = desp.data ?? [];
  const ejecutado = lista.reduce((s, d) => s + Number(d.volumen_m3), 0);
  const metaM3 = Number(meta.data?.meta_m3 ?? 0);
  const viajesMeta = meta.data?.viajes_dia ?? 12;
  const hoy = new Date();
  const diasMes = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0).getDate();
  const programadoAHoy = metaM3 * (hoy.getDate() / diasMes);
  const pct = metaM3 ? (ejecutado / metaM3) * 100 : 0;
  const deHoy = lista.filter((d) => new Date(d.fecha_salida).toDateString() === hoy.toDateString());

  const porDia = Array.from({ length: hoy.getDate() }, (_, i) => {
    const dia = i + 1;
    const m3 = lista.filter((d) => new Date(d.fecha_salida).getDate() === dia).reduce((s, d) => s + Number(d.volumen_m3), 0);
    return { dia: String(dia), m3 };
  });

  const pilas = (inv.data ?? [])
    .map((p) => ({ ...p, saldo: Number(p.volumen_m3) - Number(p.volumen_despachado_m3), dias: diasApilado(p.fecha_apilado) }))
    .filter((p) => p.saldo > 0)
    .sort((a, b) => b.dias - a.dias);
  const alertas = pilas.filter((p) => p.dias > DIAS_ALERTA_PATIO);

  async function marcarEntregado(id: string) {
    const { error } = await supabase.from("despachos").update({ estado: "entregado", fecha_entrega: new Date().toISOString() }).eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["despachos-mes"] });
    qc.invalidateQueries({ queryKey: ["control-clientes"] });
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold uppercase">Tablero de control</h1>
        <p className="text-sm text-muted-foreground">Se actualiza solo cada vez que llega un despacho.</p>
      </div>

      <section className="grid gap-4 md:grid-cols-4">
        <Kpi label="m³ ejecutados en el mes" valor={fmt(ejecutado)} sub={`de ${fmt(metaM3)} programados`} />
        <Kpi label="Cumplimiento" valor={`${pct.toFixed(1)}%`} sub={`Esperado a hoy: ${metaM3 ? ((programadoAHoy / metaM3) * 100).toFixed(0) : 0}%`} tono={ejecutado >= programadoAHoy ? "ok" : "alerta"} />
        <Kpi label="Viajes hoy" valor={`${deHoy.length} / ${viajesMeta}`} sub={`${fmt(deHoy.reduce((s, d) => s + Number(d.volumen_m3), 0))} m³ despachados hoy`} />
        <Kpi label="Pilas > 10 días" valor={String(alertas.length)} sub={`${fmt(alertas.reduce((s, p) => s + p.saldo, 0))} m³ en riesgo`} tono={alertas.length ? "mal" : "ok"} />
      </section>

      <section className="rounded-xl bg-card p-5 shadow-card">
        <div className="flex items-end justify-between">
          <h2 className="text-xl font-semibold uppercase">Avance operativo</h2>
          <span className="text-sm text-muted-foreground">{fmt(ejecutado)} / {fmt(metaM3)} m³</span>
        </div>
        <Progress value={Math.min(pct, 100)} className="mt-3 h-3" />
        <div className="mt-5 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={porDia}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="dia" tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
              <YAxis tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
              <Tooltip formatter={(v: number) => [`${fmt(v)} m³`, "Despachado"]} labelFormatter={(l) => `Día ${l}`} />
              {metaM3 > 0 && <ReferenceLine y={metaM3 / diasMes} stroke="var(--wood)" strokeDasharray="4 4" label={{ value: "meta diaria", fontSize: 11, fill: "var(--muted-foreground)" }} />}
              <Bar dataKey="m3" fill="var(--primary)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-xl bg-card p-5 shadow-card">
          <h2 className="text-xl font-semibold uppercase">Control logístico — hoy</h2>
          <ul className="mt-3 divide-y">
            {deHoy.length === 0 && <li className="py-4 text-sm text-muted-foreground">Aún no salen camiones hoy.</li>}
            {deHoy.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-3 py-2.5">
                <div>
                  <p className="font-mono font-semibold">{d.vehiculos?.placa}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(d.fecha_salida).toLocaleTimeString("es-CO", { hour: "2-digit", minute: "2-digit" })} · {d.clientes?.nombre} · {d.volumen_m3} m³
                  </p>
                </div>
                {d.estado === "entregado" ? (
                  <span className="rounded-full bg-success/15 px-2.5 py-0.5 text-xs font-medium text-success">Entregado</span>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => marcarEntregado(d.id)}>En tránsito · marcar entregado</Button>
                )}
              </li>
            ))}
            {Array.from({ length: Math.max(0, viajesMeta - deHoy.length) }).map((_, i) => (
              <li key={i} className="py-2.5 text-sm text-muted-foreground">Viaje {deHoy.length + i + 1} — programado</li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl bg-card p-5 shadow-card">
          <h2 className="text-xl font-semibold uppercase">Semáforo de patios</h2>
          <ul className="mt-3 divide-y">
            {pilas.map((p) => {
              const s = semaforoPatio(p.dias);
              return (
                <li key={p.id} className="flex items-center gap-3 py-2.5">
                  <span className={cn("h-3 w-3 shrink-0 rounded-full", s === "rojo" ? "bg-destructive" : s === "amarillo" ? "bg-warning" : "bg-success")} />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{p.patio} · Unidad {p.unidades_manejo?.codigo} · {p.productos?.especie} {p.productos?.tipo}</p>
                    <p className="text-xs text-muted-foreground">Saldo {fmt(p.saldo)} m³</p>
                  </div>
                  <span className={cn("font-display text-lg font-bold", s === "rojo" && "text-destructive")}>{p.dias} d</span>
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </div>
  );
}

function Kpi({ label, valor, sub, tono }: { label: string; valor: string; sub: string; tono?: "ok" | "alerta" | "mal" }) {
  return (
    <div className={cn("rounded-xl bg-card p-5 shadow-card border-l-4", tono === "mal" ? "border-destructive" : tono === "alerta" ? "border-warning" : "border-primary")}>
      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-4xl font-bold">{valor}</p>
      <p className="mt-1 text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}
