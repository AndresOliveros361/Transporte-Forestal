import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "Nueva contraseña — Despachos de Madera" },
    { name: "description", content: "Establece una nueva contraseña para tu cuenta de Despachos de Madera." },
    { property: "og:title", content: "Nueva contraseña — Despachos de Madera" },
    { property: "og:description", content: "Recuperación segura de acceso a Despachos de Madera." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }), component: ResetPassword,
});
function ResetPassword() {
  const [valido,setValido]=useState(false);
  const [password,setPassword]=useState("");
  const [confirmacion,setConfirmacion]=useState("");
  const [busy,setBusy]=useState(false);
  const navigate=useNavigate();
  useEffect(()=>{
    const recovery=new URLSearchParams(window.location.hash.slice(1)).get("type")==="recovery";
    if(recovery) supabase.auth.getSession().then(({data})=>setValido(Boolean(data.session)));
    const {data}=supabase.auth.onAuthStateChange(event=>{if(event==="PASSWORD_RECOVERY")setValido(true);});
    return ()=>data.subscription.unsubscribe();
  },[]);
  async function guardar(e:React.FormEvent) {
    e.preventDefault();
    if(password!==confirmacion)return void toast.error("Las contraseñas no coinciden.");
    setBusy(true);
    const {error}=await supabase.auth.updateUser({password});
    setBusy(false);
    if(error)return void toast.error(error.message);
    toast.success("Contraseña actualizada");navigate({to:"/inicio"});
  }
  return <main className="flex min-h-screen items-center justify-center bg-pine px-4 py-10"><div className="w-full max-w-sm rounded-lg bg-card p-7 shadow-card"><h1 className="text-3xl font-bold uppercase">Nueva contraseña</h1>{valido ? <form onSubmit={guardar} className="mt-5 space-y-4"><div><Label htmlFor="nueva">Nueva contraseña</Label><Input id="nueva" autoComplete="new-password" type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)}/></div><div><Label htmlFor="confirmar">Confirmar contraseña</Label><Input id="confirmar" autoComplete="new-password" type="password" required minLength={6} value={confirmacion} onChange={e=>setConfirmacion(e.target.value)}/></div><Button type="submit" disabled={busy} className="w-full">Guardar contraseña</Button></form> : <><p className="mt-4 text-sm text-muted-foreground">Abre el enlace de recuperación enviado a tu correo. Si venció, solicita uno nuevo.</p><Button variant="link" onClick={()=>navigate({to:"/auth"})}>Volver a ingresar</Button></>}</div></main>;
}