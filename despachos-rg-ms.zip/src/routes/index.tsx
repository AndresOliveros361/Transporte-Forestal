import { createFileRoute, Link } from "@tanstack/react-router";
import { Truck, WifiOff, Gauge, Building2 } from "lucide-react";
import hero from "@/assets/hero-patio.jpg";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Despachos de Madera — Campo, patios y metas" },
      {
        name: "description",
        content: "Registra despachos y entradas a patio sin señal, y sigue metas de m³ en tiempo real.",
      },
      { property: "og:title", content: "Despachos de Madera" },
      { property: "og:description", content: "Captura en campo sin conexión y tablero de despachos en tiempo real." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const items = [
  { icon: WifiOff, t: "Funciona sin señal", d: "Captura en el patio y sincroniza al llegar a la oficina." },
  { icon: Truck, t: "DESPACHOS", d: "Placa, producto y volumen con listas, sin tipear." },
  { icon: Gauge, t: "Metas y semáforo", d: "m³ ejecutados vs programados y pilas con más de 10 días." },
  { icon: Building2, t: "Clientes y pedidos", d: "Control interno de pedidos, camiones despachados y entregas." },
];

function Index() {
  return (
    <main className="min-h-screen bg-pine text-pine-foreground">
      <section className="relative min-h-[78vh] overflow-hidden">
        <img src={hero} alt="Patio de acopio de madera con camión saliendo" width={1600} height={912} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero-overlay" />

        <div className="relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-6 pb-16">
          <p className="font-display text-sm font-semibold uppercase tracking-[0.3em] text-accent">P. patula · P. maximinoi</p>
          <h1 className="mt-3 max-w-3xl text-5xl font-bold uppercase leading-[0.95] md:text-7xl">
            Despachos de madera, del patio a la planta.
          </h1>
          <p className="mt-5 max-w-xl text-lg opacity-85">
            Una sola app para supervisores en campo, patios y gerencia.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg" variant="accent">
              <Link to="/auth">Ingresar</Link>
            </Button>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-px px-6 py-16 sm:grid-cols-2 lg:grid-cols-4">
        {items.map(({ icon: Icon, t, d }) => (
          <div key={t} className="border-l border-sidebar-border p-5">
            <Icon className="h-6 w-6 text-accent" />
            <h3 className="mt-4 text-xl font-semibold uppercase">{t}</h3>
            <p className="mt-2 text-sm opacity-75">{d}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
