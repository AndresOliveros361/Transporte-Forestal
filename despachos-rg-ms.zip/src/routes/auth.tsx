import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { elegirPermanencia, mantenerSesion, prepararSesion } from "@/lib/auth-persistence";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Ingresar — Despachos de Madera" },
      { name: "description", content: "Ingresa para registrar despachos o consultar el tablero." },
      { property: "og:title", content: "Ingresar — Despachos de Madera" },
      { property: "og:description", content: "Acceso interno para supervisores, patios y gerencia." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [modo, setModo] = useState<"in" | "up" | "reset">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [cargando, setCargando] = useState(false);
  const [recordar, setRecordar] = useState(true);

  useEffect(() => {
    setRecordar(mantenerSesion());
    prepararSesion().then(() => supabase.auth.getSession()).then(({ data }) => {
      if (data.session) navigate({ to: "/inicio" });
    });
  }, [navigate]);

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    setCargando(true);
    try {
      elegirPermanencia(recordar);
      const correo = email.trim();
      if (modo === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email: correo, password });
        if (error) throw error;
        navigate({ to: "/inicio" });
      } else if (modo === "reset") {
        const { error } = await supabase.auth.resetPasswordForEmail(correo, { redirectTo: `${window.location.origin}/reset-password` });
        if (error) throw error;
        toast.success("Si el correo tiene una cuenta, recibirás un enlace para establecer tu contraseña.");
        setModo("in");
      } else {
        const { error } = await supabase.auth.signUp({
          email: correo,
          password,
          options: { emailRedirectTo: window.location.origin + "/auth" },
        });
        if (error) throw error;
        toast.success("Revisa tu correo para confirmar la cuenta.");
        setModo("in");
      }
    } catch (err) {
      const message = (err as Error).message;
      toast.error(message.includes("Invalid login credentials") ? "Correo o contraseña incorrectos. Si ingresaste con Google, puedes establecer una contraseña con «¿Olvidaste tu contraseña?»." : message.includes("Email not confirmed") ? "Confirma tu correo antes de ingresar." : message);
    } finally {
      setCargando(false);
    }
  }

  async function google() {
    elegirPermanencia(recordar);
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) return void toast.error(r.error.message);
    if (r.redirected) return;
    navigate({ to: "/inicio" });
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-pine px-4 py-10">
      <div className="w-full max-w-sm rounded-xl bg-card p-7 shadow-card">
        <img src="/icon-192.png" alt="" width={48} height={48} className="h-12 w-12 rounded-lg" />
        <h1 className="mt-4 text-3xl font-bold uppercase">{modo === "in" ? "Ingresar" : modo === "reset" ? "Recuperar acceso" : "Crear cuenta"}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Despachos de Madera</p>
        <form onSubmit={enviar} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">Correo</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
          </div>
          {modo !== "reset" && <div className="space-y-1.5">
            <Label htmlFor="pw">Contraseña</Label>
            <Input id="pw" type="password" autoComplete={modo === "in" ? "current-password" : "new-password"} required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" />
          </div>}
          {modo !== "reset" && <div className="flex items-center gap-2"><Checkbox id="recordar" checked={recordar} onCheckedChange={v=>setRecordar(v===true)}/><Label htmlFor="recordar">Mantener sesión iniciada</Label></div>}
          <Button type="submit" className="h-11 w-full" disabled={cargando}>
            {modo === "in" ? "Ingresar" : modo === "reset" ? "Enviar enlace" : "Registrarme"}
          </Button>
        </form>
        {modo === "in" && <Button variant="link" className="mt-2 w-full" onClick={()=>setModo("reset")}>¿Olvidaste tu contraseña?</Button>}
        <Button variant="outline" className="mt-3 h-11 w-full" onClick={google} disabled={cargando}>
          Continuar con Google
        </Button>
        <Button type="button" variant="link" onClick={() => setModo(modo === "in" ? "up" : "in")} className="mt-5 w-full text-center text-sm">
          {modo === "in" ? "¿No tienes cuenta? Regístrate" : "Ya tengo cuenta"}
        </Button>
      </div>
    </main>
  );
}
