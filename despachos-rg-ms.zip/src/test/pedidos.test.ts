import { describe, expect, it } from "vitest";
import { avancePedido } from "@/lib/avance-pedidos";
import { esStaff } from "@/lib/session";

describe("control interno de pedidos", () => {
  it("separa excedentes sin compensar faltantes de otros pedidos", () => {
    expect(avancePedido(30, [{ volumen_m3: 45, estado: "en_transito" }]).excesoDespachado).toBe(15);
    expect(avancePedido(30, [{ volumen_m3: 20, estado: "en_transito" }]).porDespachar).toBe(10);
  });
  it("no da acceso interno al rol cliente", () => {
    expect(esStaff(["cliente"])).toBe(false);
    expect(esStaff(["supervisor"])).toBe(true);
  });
  it("calcula despacho por los camiones vinculados", () => {
    const avance = avancePedido(90, [{ volumen_m3: 45, estado: "en_transito" }, { volumen_m3: 30, estado: "entregado" }]);
    expect(avance.despachado).toBe(75);
    expect(avance.porDespachar).toBe(15);
    expect(avance.viajes).toBe(2);
  });
  it("un camión en tránsito no cuenta como entregado", () => {
    const avance = avancePedido(90, [{ volumen_m3: 45, estado: "en_transito" }]);
    expect(avance.entregado).toBe(0);
    expect(avance.porEntregar).toBe(90);
    expect(avance.estado).toBe("En entrega");
  });
  it("completa entrega solo cuando se confirma el volumen pedido", () => {
    expect(avancePedido(90, [{ volumen_m3: 45, estado: "entregado" }, { volumen_m3: 45, estado: "entregado" }]).estado).toBe("Entregado");
    expect(avancePedido(90, [{ volumen_m3: 45, estado: "entregado" }]).estado).toBe("En entrega");
  });
});