import { describe, expect, it } from "vitest";
import { diasApilado, semaforoPatio, validarVolumenDespacho, toneladasAM3, m3AToneladas } from "@/lib/reglas";

describe("reglas de despacho", () => {
  it("maximinoi equivale a una tonelada por m3", () => {
    expect(toneladasAM3(45, "P. maximinoi")).toBe(45);
    expect(m3AToneladas(45, "PINUS MAXIMINOI")).toBe(45);
  });
  it("patula equivale a 0,85 toneladas por m3", () => {
    expect(m3AToneladas(100, "P. patula")).toBe(85);
    expect(toneladasAM3(1465, "PINO PATULA")).toBeCloseTo(1723.5294117647, 8);
    expect(validarVolumenDespacho(toneladasAM3(40, "P. patula") ?? 0)).not.toBeNull();
  });
  it("no inventa un factor para especies desconocidas", () => {
    expect(toneladasAM3(10, "Otra especie")).toBeNull();
  });
  it("acepta 45 m³ por camión", () => {
    expect(validarVolumenDespacho(45)).toBeNull();
  });
  it("rechaza más de 45 m³ por camión", () => {
    expect(validarVolumenDespacho(45.5)).not.toBeNull();
  });
  it("rechaza volumen mayor a la capacidad del vehículo", () => {
    expect(validarVolumenDespacho(40, 35)).not.toBeNull();
  });
  it("marca en rojo madera con más de 10 días apilada", () => {
    expect(semaforoPatio(11)).toBe("rojo");
    expect(semaforoPatio(10)).toBe("amarillo");
  });
  it("cuenta días apilado", () => {
    expect(diasApilado("2026-10-01", new Date(2026, 9, 12))).toBe(11);
  });
});
