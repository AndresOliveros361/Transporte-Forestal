import { beforeEach, expect, it, vi } from "vitest";
vi.mock("@/integrations/supabase/client",()=>({supabase:{auth:{signOut:vi.fn()}}}));
import { debeCerrarSesion, elegirPermanencia, mantenerSesion } from "@/lib/auth-persistence";
beforeEach(()=>{localStorage.clear();sessionStorage.clear();});
it("mantiene sesiones existentes por defecto",()=>{expect(mantenerSesion()).toBe(true);expect(debeCerrarSesion()).toBe(false);});
it("mantiene la sesión marcada después de cerrar la pestaña",()=>{elegirPermanencia(true);sessionStorage.clear();expect(debeCerrarSesion()).toBe(false);});
it("sin marcar permite recarga pero requiere ingreso en una nueva pestaña",()=>{elegirPermanencia(false);expect(debeCerrarSesion()).toBe(false);sessionStorage.clear();expect(debeCerrarSesion()).toBe(true);});
it("no elimina capturas pendientes ni catálogos sin señal",()=>{localStorage.setItem("despachos-cola-v1","pendiente");localStorage.setItem("despachos-catalogos-v1","catalogos");elegirPermanencia(false);expect(localStorage.getItem("despachos-cola-v1")).toBe("pendiente");expect(localStorage.getItem("despachos-catalogos-v1")).toBe("catalogos");});