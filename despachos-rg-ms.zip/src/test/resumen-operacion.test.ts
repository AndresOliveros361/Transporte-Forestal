import { describe, expect, it } from "vitest";
import { frecuenciaConductores, resumenDespachos } from "@/lib/resumen-operacion";

const productos = [{ id: "p", especie: "P. maximinoi", tipo: "Aserrío" }];
const viaje = { empresa: "Empresa A", conductor: "Carlos", linea_produccion: "L1", producto_id: "p", volumen_m3: 40, fecha_salida: "2026-10-27T15:00:00Z", vehiculos: { placa: "AAA123", transportador: "Terceros" } };

describe("Empresa y frecuencia independiente de conductores", () => {
  it("atribuye productividad a la empresa del viaje, no al transportador", () => {
    const grupos = resumenDespachos([viaje, { ...viaje, empresa: "Empresa B", volumen_m3: 25 }], productos, "empresa");
    expect(grupos.map(g => [g.nombre, g.viajes, g.m3])).toEqual([["EMPRESA A", 1, 40], ["EMPRESA B", 1, 25]]);
  });
  it("cuenta el mismo conductor entre empresas y placas diferentes", () => {
    const resultado = frecuenciaConductores([viaje, { ...viaje, empresa: "Empresa B", conductor: " carlos ", vehiculos: { placa: "BBB456", transportador: "Otro" } }]);
    expect(resultado).toEqual([{ nombre: "CARLOS", viajes: 2, diasActivos: 1, viajesPorDiaActivo: 2 }]);
  });
  it("cambiar de conductor no modifica la productividad por empresa", () => {
    expect(resumenDespachos([viaje], productos, "empresa")).toEqual(resumenDespachos([{ ...viaje, conductor: "Ana" }], productos, "empresa"));
  });
  it("no asigna históricos sin empresa al dueño del vehículo", () => {
    expect(resumenDespachos([{ ...viaje, empresa: null }], productos, "empresa")[0]).toMatchObject({ nombre: "Sin empresa registrada", viajes: 1, m3: 40 });
  });
  it("calcula frecuencia por días activos en hora de Colombia", () => {
    expect(frecuenciaConductores([viaje, { ...viaje, fecha_salida: "2026-10-28T03:00:00Z" }, { ...viaje, fecha_salida: "2026-10-28T15:00:00Z" }])[0]).toMatchObject({ viajes: 3, diasActivos: 2, viajesPorDiaActivo: 1.5 });
  });
});