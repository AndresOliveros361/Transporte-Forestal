import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export function AjustesOperacion() {
  const qc = useQueryClient();
  const [editor, setEditor] = useState<{ tipo: "pila" | "producto" | "linea"; id: string; nombre: string; secundario: string; observaciones?: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const { data, isPending, error } = useQuery({ queryKey: ["ajustes-operacion"], queryFn: async () => {
    const [pilas, productos, lineas] = await Promise.all([
      supabase.from("inventario_patio").select("*,productos(especie,tipo),unidades_manejo(codigo)").order("fecha_apilado", { ascending: false }),
      supabase.from("productos").select("*").order("especie"),
      supabase.from("lineas_produccion").select("*").order("nombre"),
    ]);
    const error = pilas.error || productos.error || lineas.error;
    if (error) throw error;
    return { pilas: pilas.data ?? [], productos: productos.data ?? [], lineas: lineas.data ?? [] };
  } });

  async function guardar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!editor) return;
    const f = new FormData(e.currentTarget);
    const nombre = String(f.get("nombre") ?? "").trim();
    const secundario = String(f.get("secundario") ?? "").trim();
    if (!nombre || (editor.tipo !== "linea" && !secundario)) return void toast.error("Completa los campos obligatorios.");
    setBusy(true);
    try {
      const result = editor.tipo === "pila"
        ? await supabase.from("inventario_patio").update({ patio: nombre, fecha_apilado: secundario, observaciones: String(f.get("observaciones") ?? "").trim() || null }).eq("id", editor.id).select("id").single()
        : editor.tipo === "producto"
          ? await supabase.from("productos").update({ especie: nombre, tipo: secundario }).eq("id", editor.id).select("id").single()
          : editor.id
            ? await supabase.from("lineas_produccion").update({ nombre }).eq("id", editor.id).select("id").single()
            : await supabase.from("lineas_produccion").insert({ nombre }).select("id").single();
      if (result.error) throw result.error;
      await Promise.all(["ajustes-operacion", "catalogos", "control-clientes", "inventario", "despachos-mes"].map(key => qc.invalidateQueries({ queryKey: [key] })));
      setEditor(null); toast.success("Cambios guardados");
    } catch { toast.error("No se pudo guardar. Revisa la conexión y que la línea no esté repetida."); }
    finally { setBusy(false); }
  }

  if (isPending) return <p className="text-muted-foreground">Cargando datos de operación…</p>;
  if (error || !data) return <p role="alert" className="text-destructive">No se pudieron cargar los datos de operación.</p>;
  return <>
    <section className="border-t py-5"><h2 className="text-xl font-semibold uppercase">Pilas de patio</h2><div className="mt-3 overflow-x-auto"><table className="w-full text-left text-sm"><thead className="border-b text-xs uppercase text-muted-foreground"><tr>{["Patio / unidad", "Producto", "Apilado", "Saldo m³", ""].map((h,i)=><th key={i} className="p-3">{h}</th>)}</tr></thead><tbody className="divide-y">{data.pilas.map(p=><tr key={p.id}><td className="p-3">{p.patio} · {p.unidades_manejo?.codigo}</td><td className="p-3">{p.productos?.especie} · {p.productos?.tipo}</td><td className="whitespace-nowrap p-3">{p.fecha_apilado}</td><td className="p-3">{(Number(p.volumen_m3)-Number(p.volumen_despachado_m3)).toLocaleString("es-CO")}</td><td className="p-3"><Button variant="ghost" size="icon" aria-label={`Editar pila ${p.patio}`} onClick={()=>setEditor({tipo:"pila",id:p.id,nombre:p.patio,secundario:p.fecha_apilado,observaciones:p.observaciones ?? ""})}><Pencil className="h-4 w-4"/></Button></td></tr>)}{!data.pilas.length && <tr><td colSpan={5} className="py-5 text-muted-foreground">Sin pilas registradas.</td></tr>}</tbody></table></div></section>
    <section className="border-t py-5"><div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold uppercase">Líneas de producción</h2><Button variant="outline" onClick={()=>setEditor({tipo:"linea",id:"",nombre:"",secundario:""})}><Plus className="mr-2 h-4 w-4"/>Nueva línea</Button></div><ul className="mt-3 divide-y">{data.lineas.map(l=><li key={l.id} className="flex items-center justify-between gap-3 py-3"><span>{l.nombre}</span><Button variant="ghost" size="icon" aria-label={`Editar línea ${l.nombre}`} onClick={()=>setEditor({tipo:"linea",id:l.id,nombre:l.nombre,secundario:""})}><Pencil className="h-4 w-4"/></Button></li>)}</ul>{!data.lineas.length && <p className="mt-3 text-sm text-muted-foreground">Sin líneas registradas.</p>}</section>
    <Dialog open={editor!==null} onOpenChange={open=>{if(!open && !busy)setEditor(null);}}><DialogContent aria-describedby={undefined}><DialogHeader><DialogTitle>{editor?.tipo==="pila" ? "Editar pila de patio" : editor?.tipo==="producto" ? "Editar producto" : editor?.id ? "Editar línea de producción" : "Nueva línea de producción"}</DialogTitle></DialogHeader>{editor && <form key={`${editor.tipo}-${editor.id}`} onSubmit={guardar} className="space-y-4"><div className="space-y-1.5"><Label htmlFor="operacion-nombre">{editor.tipo==="pila" ? "Patio" : editor.tipo==="producto" ? "Especie" : "Nombre de línea"}</Label><Input id="operacion-nombre" name="nombre" required defaultValue={editor.nombre}/></div>{editor.tipo!=="linea" && <div className="space-y-1.5"><Label htmlFor="operacion-secundario">{editor.tipo==="pila" ? "Fecha de apilado" : "Tipo de producto"}</Label><Input id="operacion-secundario" name="secundario" type={editor.tipo==="pila" ? "date" : "text"} required defaultValue={editor.secundario}/></div>}{editor.tipo==="pila" && <div className="space-y-1.5"><Label htmlFor="operacion-obs">Observaciones</Label><Input id="operacion-obs" name="observaciones" defaultValue={editor.observaciones}/></div>}{editor.tipo==="producto" && <p className="text-sm text-warning">El cambio de nombre también se verá en pedidos y despachos asociados.</p>}<Button type="submit" disabled={busy}>{busy ? "Guardando…" : "Guardar cambios"}</Button></form>}</DialogContent></Dialog>
  </>;
}