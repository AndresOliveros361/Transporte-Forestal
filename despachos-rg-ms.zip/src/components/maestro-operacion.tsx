import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Download } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { cargarCatalogos } from "@/lib/offline";
import { nombreProducto } from "@/lib/maestro";
import { VOLUMEN_MAX_CAMION_M3 } from "@/lib/reglas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const tipos = { vehiculo: "Vehículos", conductor: "Conductores", cliente: "Clientes", destino: "Destinos", finca: "Fincas", rodal: "Rodales", patio: "Patios", especie: "Especies", producto: "Productos", pedido: "Pedidos de clientes" };
type Tipo = keyof typeof tipos;
type Editor = { tipo: Exclude<Tipo, "pedido">; id: string; nombre: string; secundario?: string; dimension?: string; relacion?: string; capacidad?: number; conductor?: string };
const selectCls = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm";

export function MaestroOperacion() {
  const qc = useQueryClient();
  const [tipo, setTipo] = useState<Tipo>("vehiculo");
  const [buscar, setBuscar] = useState("");
  const [editor, setEditor] = useState<Editor | null>(null);
  const [busy, setBusy] = useState(false);
  const { data: cat, error } = useQuery({ queryKey: ["catalogos"], queryFn: cargarCatalogos });
  if (!cat) return <p role={error ? "alert" : undefined}>{error ? "No se pudo cargar el maestro." : "Cargando maestro…"}</p>;
  const maestro = cat.maestro ?? [];
  const filas = tipo === "vehiculo" ? cat.vehiculos.map(v => ({ id: v.id, nombre: v.placa, detalle: [v.transportador, maestro.find(d => d.id === v.conductor_id)?.nombre, `${v.capacidad_m3} m³`].filter(Boolean).join(" · "), editor: { tipo, id: v.id, nombre: v.placa, secundario: v.transportador ?? "", capacidad: v.capacidad_m3, conductor: v.conductor_id ?? "" } as Editor }))
    : tipo === "cliente" ? cat.clientes.map(c => ({ id: c.id, nombre: c.nombre, detalle: c.planta, editor: { tipo, id: c.id, nombre: c.nombre, secundario: c.planta } as Editor }))
    : tipo === "producto" ? cat.productos.map(p => ({ id: p.id, nombre: nombreProducto(p), detalle: "", editor: { tipo, id: p.id, nombre: p.especie, secundario: p.tipo, dimension: p.dimension ?? "" } as Editor }))
    : tipo === "pedido" ? (cat.pedidos ?? []).map(p => ({ id: p.id, nombre: p.numero, detalle: `${cat.clientes.find(c => c.id === p.cliente_id)?.nombre ?? ""} · ${p.descripcion_producto || nombreProducto(cat.productos.find(d => d.id === p.producto_id) ?? { especie: "", tipo: "" })} · ${p.volumen_m3} m³`, editor: null }))
    : maestro.filter(d => d.tipo === tipo).map(d => ({ id: d.id, nombre: d.nombre, detalle: d.cliente_id ? cat.clientes.find(c => c.id === d.cliente_id)?.nombre ?? "" : maestro.find(p => p.id === d.padre_id)?.nombre ?? "", editor: { tipo, id: d.id, nombre: d.nombre, relacion: d.cliente_id ?? d.padre_id ?? "" } as Editor }));

  async function guardar(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!editor) return;
    const f = new FormData(e.currentTarget);
    const nombre = String(f.get("nombre") ?? "").trim();
    const secundario = String(f.get("secundario") ?? "").trim();
    const relacion = String(f.get("relacion") ?? "");
    if (!nombre) return;
    const cap = Number(f.get("capacidad"));
    if (editor.tipo === "vehiculo" && (!(cap > 0) || cap > VOLUMEN_MAX_CAMION_M3)) return void toast.error("La capacidad debe ser mayor a 0 y máximo 45 m³.");
    setBusy(true);
    try {
      const id = editor.id;
      const result = editor.tipo === "vehiculo" ? await supabase.from("vehiculos").upsert({ ...(id ? { id } : {}), placa: nombre.toUpperCase(), transportador: secundario || null, capacidad_m3: cap, conductor_id: String(f.get("conductor") ?? "") || null }).select("id").single()
        : editor.tipo === "cliente" ? await supabase.from("clientes").upsert({ ...(id ? { id } : {}), nombre, planta: secundario }).select("id").single()
        : editor.tipo === "producto" ? await supabase.from("productos").upsert({ ...(id ? { id } : {}), especie: nombre, tipo: secundario, dimension: String(f.get("dimension") ?? "").trim() || null }).select("id").single()
        : await supabase.from("maestro_operacion").upsert({ ...(id ? { id } : {}), tipo: editor.tipo, nombre, padre_id: editor.tipo === "rodal" ? relacion || null : null, cliente_id: editor.tipo === "destino" ? relacion || null : null }).select("id").single();
      if (result.error) throw result.error;
      await Promise.all(["catalogos", "ajustes-operacion", "control-clientes", "despachos-mes", "vehiculos"].map(key => qc.invalidateQueries({ queryKey: [key] })));
      setEditor(null); toast.success("Maestro actualizado");
    } catch { toast.error("No se pudo guardar. Revisa la conexión y los datos repetidos."); }
    finally { setBusy(false); }
  }
  function descargar() {
    if (!cat) return;
    const content = JSON.stringify(cat, null, 2);
    const url = URL.createObjectURL(new Blob([content], { type: "application/json" }));
    const a = document.createElement("a"); a.href = url; a.download = "maestro-operacion.json"; a.click(); URL.revokeObjectURL(url);
  }
  return <section className="space-y-4 border-y py-5">
    <div className="flex flex-wrap items-center justify-between gap-3"><h2 className="text-xl font-semibold uppercase">Archivo maestro</h2><Button variant="outline" onClick={descargar}><Download className="mr-2 h-4 w-4"/>Descargar maestro</Button></div>
    <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto]"><select aria-label="Lista del maestro" className={selectCls} value={tipo} onChange={e => { setTipo(e.target.value as Tipo); setBuscar(""); }}>{Object.entries(tipos).map(([k,v]) => <option key={k} value={k}>{v}</option>)}</select><Input aria-label="Buscar en maestro" placeholder="Buscar…" value={buscar} onChange={e => setBuscar(e.target.value)}/>{tipo !== "pedido" && <Button onClick={() => setEditor({ tipo, id: "", nombre: "", capacidad: VOLUMEN_MAX_CAMION_M3 })}><Plus className="mr-2 h-4 w-4"/>Agregar</Button>}</div>
    <ul className="divide-y">{filas.filter(f => `${f.nombre} ${f.detalle}`.toLocaleLowerCase("es").includes(buscar.toLocaleLowerCase("es"))).map(f => <li key={f.id} className="flex items-center justify-between gap-3 py-3"><div className="min-w-0 break-words"><p className="font-medium">{f.nombre}</p><p className="text-sm text-muted-foreground">{f.detalle}</p></div>{f.editor && <Button variant="ghost" size="icon" aria-label={`Editar ${f.nombre}`} onClick={() => setEditor(f.editor)}><Pencil className="h-4 w-4"/></Button>}</li>)}</ul>{!filas.length && <p className="text-sm text-muted-foreground">Sin registros.</p>}
    <Dialog open={editor !== null} onOpenChange={open => { if (!open && !busy) setEditor(null); }}><DialogContent aria-describedby={undefined}><DialogHeader><DialogTitle>{editor?.id ? "Editar" : "Agregar"} · {editor ? tipos[editor.tipo] : ""}</DialogTitle></DialogHeader>{editor && <form onSubmit={guardar} className="space-y-4" key={`${editor.tipo}-${editor.id}`}>
      <div><Label htmlFor="maestro-nombre">{editor.tipo === "vehiculo" ? "Placa" : editor.tipo === "producto" ? "Especie" : "Nombre"}</Label><Input id="maestro-nombre" name="nombre" list={editor.tipo === "producto" ? "maestro-especies" : undefined} required defaultValue={editor.nombre}/><datalist id="maestro-especies">{maestro.filter(d => d.tipo === "especie").map(d => <option key={d.id} value={d.nombre}/>)}</datalist></div>
      {["vehiculo", "cliente", "producto"].includes(editor.tipo) && <div><Label htmlFor="maestro-secundario">{editor.tipo === "vehiculo" ? "Transportador" : editor.tipo === "cliente" ? "Planta / destino principal" : "Tipo de producto"}</Label><Input id="maestro-secundario" name="secundario" required={editor.tipo !== "vehiculo"} defaultValue={editor.secundario} list={editor.tipo === "producto" ? "maestro-tipos" : undefined}/><datalist id="maestro-tipos"><option value="Aserrío"/><option value="Inmuniza"/><option value="Astillable"/></datalist></div>}
      {editor.tipo === "producto" && <div><Label htmlFor="maestro-dimension">Dimensión / combinación</Label><Input id="maestro-dimension" name="dimension" defaultValue={editor.dimension} placeholder="2.20 m / 2.50 m"/></div>}
      {editor.tipo === "vehiculo" && <><div><Label htmlFor="maestro-capacidad">Capacidad (m³)</Label><Input id="maestro-capacidad" name="capacidad" inputMode="decimal" required defaultValue={editor.capacidad}/></div><div><Label htmlFor="maestro-conductor">Conductor habitual</Label><select id="maestro-conductor" name="conductor" className={selectCls} defaultValue={editor.conductor ?? ""}><option value="">Sin asignar</option>{maestro.filter(d => d.tipo === "conductor").map(d => <option key={d.id} value={d.id}>{d.nombre}</option>)}</select></div></>}
      {(editor.tipo === "destino" || editor.tipo === "rodal") && <div><Label htmlFor="maestro-relacion">{editor.tipo === "destino" ? "Cliente" : "Finca"}</Label><select id="maestro-relacion" name="relacion" required className={selectCls} defaultValue={editor.relacion ?? ""}><option value="">Seleccionar…</option>{(editor.tipo === "destino" ? cat.clientes : maestro.filter(d => d.tipo === "finca")).map(d => <option key={d.id} value={d.id}>{d.nombre}</option>)}</select></div>}
      {editor.tipo === "producto" && editor.id && <p className="text-sm text-warning">El cambio se verá en los pedidos e inventario asociados.</p>}
      <Button type="submit" disabled={busy}>{busy ? "Guardando…" : "Guardar"}</Button>
    </form>}</DialogContent></Dialog>
  </section>;
}