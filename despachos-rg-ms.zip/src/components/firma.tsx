export function Firma() {
  return <div className="flex min-h-9 items-center justify-end border-b bg-background px-4 py-2 text-right"><p className="font-display text-xs font-semibold text-foreground">By Ing Andres Oliveros</p></div>;
}