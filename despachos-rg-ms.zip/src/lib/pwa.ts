// Único punto de registro del modo sin conexión. Nunca se activa en la vista
// previa del editor ni en desarrollo; solo en la app publicada.
const PREVIEW_LABEL = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/;

function contextoBloqueado(): boolean {
  if (!import.meta.env.PROD) return true;
  try {
    if (window.self !== window.top) return true;
  } catch {
    return true;
  }
  const host = window.location.hostname.toLowerCase();
  const label = host.split(".")[0] ?? "";
  const previewDomains = [".lovable.app", ".gpt-eng.com", ".gptengineer.run"];
  if (previewDomains.some((d) => host.endsWith(d)) && PREVIEW_LABEL.test(label)) return true;
  if (/^project--[a-z0-9-]+-dev\./.test(host)) return true;
  if (host === "lovableproject.com" || host.endsWith(".lovableproject.com")) return true;
  if (host === "lovableproject-dev.com" || host.endsWith(".lovableproject-dev.com")) return true;
  if (host === "beta.lovable.dev" || host.endsWith(".beta.lovable.dev")) return true;
  if (new URLSearchParams(window.location.search).get("sw") === "off") return true;
  return false;
}

async function quitarRegistros() {
  if (!("serviceWorker" in navigator)) return;
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.all(
    regs
      .filter((r) => (r.active ?? r.installing ?? r.waiting)?.scriptURL.endsWith("/sw.js"))
      .map((r) => r.unregister()),
  );
}

export async function registrarModoOffline() {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
  if (contextoBloqueado()) {
    await quitarRegistros();
    return;
  }
  const { registerSW } = await import("virtual:pwa-register");
  registerSW({ immediate: true });
}
