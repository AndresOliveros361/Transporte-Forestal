import { useSyncExternalStore } from "react";
import type { DatoMaestro } from "@/lib/maestro";
import { supabase } from "@/integrations/supabase/client";

// Cola local de registros capturados en campo. Se guarda en el teléfono y se
// envía al servidor cuando hay conexión. Cada registro lleva su id propio, así
// reenviarlo nunca crea duplicados.
export type TipoRegistro = "despacho" | "inventario";
export type RegistroPendiente = {
  id: string;
  tipo: TipoRegistro;
  datos: Record<string, unknown>;
  resumen: string;
  creado: string;
  error?: string;
};

const COLA_KEY = "despachos-cola-v1";
const CAT_KEY = "despachos-catalogos-v1";
const listeners = new Set<() => void>();
let snapshot: RegistroPendiente[] | null = null;

function leer(): RegistroPendiente[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(COLA_KEY) ?? "[]");
  } catch {
    return [];
  }
}
function escribir(cola: RegistroPendiente[]) {
  localStorage.setItem(COLA_KEY, JSON.stringify(cola));
  snapshot = cola;
  listeners.forEach((l) => l());
}

export function agregarACola(r: Omit<RegistroPendiente, "creado">) {
  escribir([...leer(), { ...r, creado: new Date().toISOString() }]);
}
export function eliminarDeCola(id: string) {
  escribir(leer().filter((r) => r.id !== id));
}

const EMPTY: RegistroPendiente[] = [];
export function useCola() {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => (snapshot ??= leer()),
    () => EMPTY,
  );
}

let sincronizando = false;
export async function sincronizarCola(): Promise<{ enviados: number; fallidos: number }> {
  if (sincronizando || typeof navigator === "undefined" || !navigator.onLine)
    return { enviados: 0, fallidos: 0 };
  sincronizando = true;
  let enviados = 0;
  let fallidos = 0;
  try {
    // Inventario primero: los despachos pueden referenciar una pila nueva.
    const cola = [...leer()].sort((a, b) => (a.tipo === b.tipo ? 0 : a.tipo === "inventario" ? -1 : 1));
    for (const r of cola) {
      const tabla = r.tipo === "despacho" ? "despachos" : "inventario_patio";
      const { error } = await supabase
        .from(tabla)
        .upsert(r.datos as never, { onConflict: "id", ignoreDuplicates: true });
      if (error) {
        fallidos++;
        escribir(leer().map((x) => (x.id === r.id ? { ...x, error: error.message } : x)));
      } else {
        enviados++;
        eliminarDeCola(r.id);
      }
    }
  } finally {
    sincronizando = false;
  }
  return { enviados, fallidos };
}

// Catálogos (placas, productos, clientes...) guardados para usar sin señal.
export type Catalogos = {
  vehiculos: { id: string; placa: string; transportador: string | null; capacidad_m3: number; conductor_id?: string | null }[];
  productos: { id: string; especie: string; tipo: string; dimension?: string | null }[];
  clientes: { id: string; nombre: string; planta: string }[];
  unidades: { id: string; codigo: string; nombre: string }[];
  pedidos?: { id: string; numero: string; cliente_id: string; producto_id: string; volumen_m3: number; descripcion_producto?: string | null }[];
  maestro?: DatoMaestro[];
  lineas?: { id: string; nombre: string }[];
  inventario: {
    id: string;
    patio: string;
    unidad_id: string;
    producto_id: string;
    volumen_m3: number;
    volumen_despachado_m3: number;
    fecha_apilado: string;
  }[];
  actualizado: string;
};

export function catalogosGuardados(): Catalogos | null {
  try {
    const raw = localStorage.getItem(CAT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export async function cargarCatalogos(): Promise<Catalogos> {
  const guardados = catalogosGuardados();
  if (!navigator.onLine && guardados) return guardados;
  try {
    const [v, p, c, u, i, pedidos, lineas, maestro] = await Promise.all([
      supabase.from("vehiculos").select("id, placa, transportador, capacidad_m3, conductor_id").order("placa"),
      supabase.from("productos").select("id, especie, tipo, dimension").order("especie"),
      supabase.from("clientes").select("id, nombre, planta").order("nombre"),
      supabase.from("unidades_manejo").select("id, codigo, nombre").order("codigo"),
      supabase
        .from("inventario_patio")
        .select("id, patio, unidad_id, producto_id, volumen_m3, volumen_despachado_m3, fecha_apilado")
        .order("fecha_apilado"),
      supabase.from("pedidos").select("id,numero,cliente_id,producto_id,volumen_m3,descripcion_producto").order("created_at", { ascending: false }),
      supabase.from("lineas_produccion").select("id,nombre").order("nombre"),
      supabase.from("maestro_operacion").select("*").order("nombre"),
    ]);
    const err = v.error || p.error || c.error || u.error || i.error || pedidos.error || lineas.error || maestro.error;
    if (err) throw err;
    const cat: Catalogos = {
      vehiculos: v.data ?? [],
      productos: p.data ?? [],
      clientes: c.data ?? [],
      unidades: u.data ?? [],
      inventario: i.data ?? [],
      pedidos: pedidos.data ?? [],
      lineas: lineas.data ?? [],
      maestro: maestro.data ?? [],
      actualizado: new Date().toISOString(),
    };
    localStorage.setItem(CAT_KEY, JSON.stringify(cat));
    return cat;
  } catch (e) {
    if (guardados) return guardados;
    throw e;
  }
}
