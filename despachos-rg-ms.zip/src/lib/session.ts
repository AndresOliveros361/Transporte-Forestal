import { supabase } from "@/integrations/supabase/client";
import { prepararSesion } from "@/lib/auth-persistence";

export type Rol = "admin" | "supervisor" | "jefe_patio" | "transportador" | "cliente";
const ROLES_KEY = "despachos-roles-v1";

// Sin señal no podemos validar con el servidor: usamos la sesión guardada.
export async function usuarioActual() {
  await prepararSesion();
  if (typeof navigator !== "undefined" && !navigator.onLine) {
    const { data } = await supabase.auth.getSession();
    return data.session?.user ?? null;
  }
  const { data } = await supabase.auth.getUser();
  return data.user ?? null;
}

export async function misRoles(userId: string): Promise<Rol[]> {
  const key = `${ROLES_KEY}:${userId}`;
  if (!navigator.onLine) {
    return JSON.parse(localStorage.getItem(key) ?? "[]");
  }
  const { data } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  const roles = (data ?? []).map((r) => r.role as Rol);
  localStorage.setItem(key, JSON.stringify(roles));
  return roles;
}

export const ROL_LABEL: Record<Rol, string> = {
  admin: "Administrador",
  supervisor: "Supervisor de campo",
  jefe_patio: "Jefe de patio",
  transportador: "Transportador",
  cliente: "Cliente",
};

export const puedeCapturar = (r: Rol[]) => r.some((x) => ["admin", "supervisor", "jefe_patio"].includes(x));
export const esStaff = (r: Rol[]) => r.some((x) => x !== "cliente");
