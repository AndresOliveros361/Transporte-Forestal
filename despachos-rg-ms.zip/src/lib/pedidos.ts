import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Pedido = Database["public"]["Tables"]["pedidos"]["Row"];
export type Viaje = Database["public"]["Tables"]["despachos"]["Row"] & {
  vehiculos: { placa: string } | null;
};

export async function cargarControl() {
  const [pedidos, clientes, productos] = await Promise.all([
    supabase.from("pedidos").select("*").order("created_at", { ascending: false }),
    supabase.from("clientes").select("id,nombre,planta").order("nombre"),
    supabase.from("productos").select("id,especie,tipo,dimension").order("especie"),
  ]);
  const error = pedidos.error || clientes.error || productos.error;
  if (error) throw error;
  const viajes: Viaje[] = [];
  for (let start = 0; ; start += 1000) {
    const result = await supabase.from("despachos").select("*,vehiculos(placa)")
      .order("fecha_salida", { ascending: false }).order("id").range(start, start + 999);
    if (result.error) throw result.error;
    viajes.push(...(result.data ?? []));
    if ((result.data?.length ?? 0) < 1000) break;
  }
  return { pedidos: pedidos.data ?? [], clientes: clientes.data ?? [], productos: productos.data ?? [], viajes };
}

export const controlOptions = queryOptions({ queryKey: ["control-clientes"], queryFn: cargarControl, refetchInterval: 30_000 });