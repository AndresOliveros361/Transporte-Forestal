export type ViajePedido = { volumen_m3: number; estado: string };

export function avancePedido(meta: number, viajes: ViajePedido[]) {
  const despachado = viajes.reduce((s, v) => s + Number(v.volumen_m3), 0);
  const entregado = viajes.filter((v) => v.estado === "entregado").reduce((s, v) => s + Number(v.volumen_m3), 0);
  return {
    despachado, entregado, enTransito: despachado - entregado,
    porDespachar: Math.max(0, meta - despachado),
    excesoDespachado: Math.max(0, despachado - meta),
    porEntregar: Math.max(0, meta - entregado),
    porcentaje: meta > 0 ? Math.min(100, entregado / meta * 100) : 0,
    estado: entregado >= meta ? "Entregado" : despachado === 0 ? "Pendiente" : "En entrega",
    viajes: viajes.length,
  };
}