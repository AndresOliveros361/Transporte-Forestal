import type { Database } from "@/integrations/supabase/types";

export type DatoMaestro = Database["public"]["Tables"]["maestro_operacion"]["Row"];
export const PEDIDO_OTRO = "otro";
export function nombreProducto(p: { especie: string; tipo: string; dimension?: string | null }) {
  return [p.especie, p.tipo, p.dimension].filter(Boolean).join(" · ");
}
export function opcionesMaestro(datos: DatoMaestro[], tipo: string, filtro?: { padre_id?: string; cliente_id?: string }) {
  return datos.filter(d => d.tipo === tipo && (!filtro?.padre_id || d.padre_id === filtro.padre_id) && (!filtro?.cliente_id || d.cliente_id === filtro.cliente_id));
}
export function referenciaPedido(valor: string, adicional: string) {
  return { pedido_id: valor && valor !== PEDIDO_OTRO ? valor : null, pedido_adicional: valor === PEDIDO_OTRO ? adicional.trim() : null };
}