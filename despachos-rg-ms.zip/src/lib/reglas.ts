// Reglas de negocio de despachos y patios.
export const VOLUMEN_MAX_CAMION_M3 = 45;
export const DIAS_ALERTA_PATIO = 10;

export function factorToneladas(especie: string): number | null {
  const nombre = especie.toLowerCase();
  if (nombre.includes("patula")) return 0.85;
  if (nombre.includes("maximino")) return 1;
  return null;
}

export function toneladasAM3(toneladas: number, especie: string): number | null {
  const factor = factorToneladas(especie);
  return factor === null || !Number.isFinite(toneladas) || toneladas < 0 ? null : toneladas / factor;
}

export function m3AToneladas(volumen: number, especie: string): number | null {
  const factor = factorToneladas(especie);
  return factor === null || !Number.isFinite(volumen) || volumen < 0 ? null : volumen * factor;
}

export function validarVolumenDespacho(volumen: number, capacidadVehiculo?: number): string | null {
  if (!Number.isFinite(volumen) || volumen <= 0) return "El volumen debe ser mayor a 0 m³.";
  if (volumen > VOLUMEN_MAX_CAMION_M3)
    return `El volumen máximo por camión es ${VOLUMEN_MAX_CAMION_M3} m³.`;
  if (capacidadVehiculo != null && volumen > capacidadVehiculo)
    return `Este vehículo solo admite ${capacidadVehiculo} m³.`;
  return null;
}

export function diasApilado(fechaApilado: string, hoy: Date = new Date()): number {
  const [y = 0, m = 1, d = 1] = fechaApilado.slice(0, 10).split("-").map(Number);
  const inicio = Date.UTC(y, m - 1, d);
  const fin = Date.UTC(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
  return Math.max(0, Math.floor((fin - inicio) / 86400000));
}

export type Semaforo = "verde" | "amarillo" | "rojo";
export function semaforoPatio(dias: number): Semaforo {
  if (dias > DIAS_ALERTA_PATIO) return "rojo";
  if (dias > 5) return "amarillo";
  return "verde";
}

export function generarRemision(fecha: Date = new Date()): string {
  const p = (n: number) => String(n).padStart(2, "0");
  const rnd = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `REM-${String(fecha.getFullYear()).slice(2)}${p(fecha.getMonth() + 1)}${p(fecha.getDate())}-${rnd}`;
}
