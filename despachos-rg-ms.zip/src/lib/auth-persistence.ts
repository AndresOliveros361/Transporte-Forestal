import { supabase } from "@/integrations/supabase/client";

const PREFERENCE = "despachos-mantener-sesion";
const TAB = "despachos-sesion-pestana";
export function mantenerSesion(): boolean {
  return localStorage.getItem(PREFERENCE) !== "no";
}
export function elegirPermanencia(remember: boolean) {
  localStorage.setItem(PREFERENCE, remember ? "si" : "no");
  sessionStorage.setItem(TAB, "activa");
}
export function debeCerrarSesion(): boolean {
  return !mantenerSesion() && sessionStorage.getItem(TAB) !== "activa";
}
let preparacion: Promise<void> | undefined;
export function prepararSesion() {
  preparacion ??= (async () => {
    if (debeCerrarSesion()) await supabase.auth.signOut({ scope: "local" });
  })();
  return preparacion;
}