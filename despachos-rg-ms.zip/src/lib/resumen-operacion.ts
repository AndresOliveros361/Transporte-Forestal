import { m3AToneladas } from "@/lib/reglas";

type ViajeOperacion = {
  empresa?: string | null;
  conductor: string | null;
  linea_produccion: string | null;
  producto_id: string;
  volumen_m3: number;
  fecha_salida: string;
};
type Producto = { id: string; especie: string; tipo: string };
const normalizar = (nombre: string | null | undefined, vacio: string) =>
  nombre?.trim().replace(/\s+/g, " ").toLocaleUpperCase("es-CO") || vacio;

export function resumenDespachos(viajes: ViajeOperacion[], productos: Producto[], tipo: "empresa" | "linea") {
  const grupos = new Map<string, { nombre: string; producto: string; viajes: number; m3: number; ton: number; sinFactor: number }>();
  for (const v of viajes) {
    const p = productos.find(p => p.id === v.producto_id);
    const nombre = tipo === "empresa" ? normalizar(v.empresa, "Sin empresa registrada") : normalizar(v.linea_produccion, "Sin línea");
    const producto = tipo === "linea" ? p?.tipo ?? "Sin producto" : "";
    const key = JSON.stringify([nombre, producto]);
    const g = grupos.get(key) ?? { nombre, producto, viajes: 0, m3: 0, ton: 0, sinFactor: 0 };
    const peso = m3AToneladas(Number(v.volumen_m3), p?.especie ?? "");
    g.viajes++; g.m3 += Number(v.volumen_m3); g.ton += peso ?? 0;
    if (peso === null) g.sinFactor++;
    grupos.set(key, g);
  }
  return [...grupos.values()].sort((a, b) => b.m3 - a.m3);
}

export function frecuenciaConductores(viajes: ViajeOperacion[]) {
  const grupos = new Map<string, { nombre: string; viajes: number; dias: Set<string> }>();
  for (const v of viajes) {
    const nombre = normalizar(v.conductor, "Sin conductor registrado");
    const g = grupos.get(nombre) ?? { nombre, viajes: 0, dias: new Set<string>() };
    g.viajes++;
    g.dias.add(new Date(v.fecha_salida).toLocaleDateString("en-CA", { timeZone: "America/Bogota" }));
    grupos.set(nombre, g);
  }
  return [...grupos.values()].map(g => ({ nombre: g.nombre, viajes: g.viajes, diasActivos: g.dias.size, viajesPorDiaActivo: g.viajes / g.dias.size })).sort((a, b) => b.viajes - a.viajes || a.nombre.localeCompare(b.nombre));
}