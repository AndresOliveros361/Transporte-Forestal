import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type DespachoFila = {
  id: string;
  remision: string;
  volumen_m3: number;
  fecha_salida: string;
  estado: string;
  vehiculos: { placa: string; transportador: string | null } | null;
  clientes: { nombre: string; planta: string } | null;
  productos: { especie: string; tipo: string } | null;
  unidades_manejo: { codigo: string } | null;
};

export async function despachosDesde(desde: Date): Promise<DespachoFila[]> {
  const { data, error } = await supabase
    .from("despachos")
    .select("id, remision, volumen_m3, fecha_salida, estado, vehiculos(placa, transportador), clientes(nombre, planta), productos(especie, tipo), unidades_manejo(codigo)")
    .gte("fecha_salida", desde.toISOString())
    .order("fecha_salida", { ascending: false })
    .limit(1000);
  if (error) throw error;
  return (data ?? []) as unknown as DespachoFila[];
}

// Refresca los tableros cada vez que llega un despacho o cambia un patio.
export function useTiempoReal(keys: string[][]) {
  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase
      .channel(`tablero-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "despachos" }, () => keys.forEach((k) => qc.invalidateQueries({ queryKey: k })))
      .on("postgres_changes", { event: "*", schema: "public", table: "inventario_patio" }, () => keys.forEach((k) => qc.invalidateQueries({ queryKey: k })))
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qc]);
}
