## Firma y acceso
- [x] Mostrar la firma exacta arriba a la derecha en todas las pantallas.
- [x] Comprobar habilitación del acceso por contraseña y rechazo de credenciales incorrectas; agregar recuperación de contraseña.
- [x] Ofrecer permanencia de sesión y verificar comportamiento.
- [ ] Verificar un ingreso exitoso con contraseña real y entrega del correo de recuperación: sin credenciales de prueba disponibles ni enlace de recuperación recibido.

## Maestro interconectado
- [ ] Crear maestro editable de vehículos, conductores, clientes/destinos, fincas/rodales, patios y productos dimensionados.
- [ ] Conectar listas de campo, pedidos y consultas, conservando captura offline y solicitudes «Otro».
- [ ] Retirar asignación de roles de la app y restringir cambios al proyecto.
- [ ] Verificar guardado, relaciones y consultas.

## Edición en Ajustes
- [x] Editar pilas de patio y productos existentes.
- [x] Crear y editar líneas de producción disponibles en campo sin señal.
- [x] Verificar guardado y actualización de listas.

## Empresas y frecuencia de conductores
- [x] Guardar empresa por viaje desde campo, también sin señal.
- [x] Mostrar despachos por empresa y frecuencia informativa por conductor entre empresas y vehículos.
- [x] Probar cálculos y verificar captura, sincronización y consulta.

## Control interno de clientes
- [x] Registrar pedidos con cliente, producto, volumen y fecha prevista.
- [x] Vincular camiones despachados a pedidos, también desde captura sin señal.
- [x] Mostrar avance despachado y entregado; confirmar recepción.
- [x] Reemplazar referencias al portal externo y restringir acceso interno.
- [x] Probar cálculos, permisos y el recorrido completo.

## Alineación con controles de Excel
- [x] Comparar registros de mayo y octubre con el control actual.
- [x] Confirmar m³ como unidad principal y conversiones por especie.
- [x] Incorporar descripción, especificación y precio por m³ en pedidos; pendientes y excedentes separados.
- [x] Incorporar línea, conductor, finca y rodal en captura offline y consultas mensuales.
- [x] Verificar conversiones, persistencia y captura offline.